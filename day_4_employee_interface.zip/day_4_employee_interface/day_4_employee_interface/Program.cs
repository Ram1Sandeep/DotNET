﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee(123, "ram", "Guntur", 30000, "Srinagar", "IOT", 5, 123, "state bank", 22);
            HR obj1 = new HR();
            Account obj2 = new Account();
            Manager obj3 = new Manager();

            obj1.GetEmployee(emp);
            obj2.GetEmployee(emp);
            obj3.GetEmployee(emp);

            Console.ReadLine();

            
                  
        }
    }
}
