﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_3_Assignment_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the OrderID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Customer Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Item Qty");
            int qty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Item Price:");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Type of Order:");
            string type = Console.ReadLine();

            Order obj = null;
            if (type == "Order")
            {

                obj = new Order(id, name, qty, price);
            }
            else if(type=="Overseas")
            {
                obj = new Order_Overseas(id, name, qty, price);
            }
            if (obj != null)
            {
                int value = obj.GetOrderValue();
                Console.WriteLine(value);
                Console.ReadLine();
            }
        }
        
        
    }
}
