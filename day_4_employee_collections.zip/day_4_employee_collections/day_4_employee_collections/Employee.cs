﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_collections
{
    class Employee
    {
        public delegate void delleave(int id, string reason);
        public event delleave evtleave;


        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private static int Count = 1000;

        public Employee(string EmployeeName, string EmployeeCity)
        {
            Employee.Count++;
            this.EmployeeID = Employee.Count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PEmployeeID { get { return this.EmployeeID; } }
        public string PEmployeeName { get { return this.EmployeeName; } }
        public string PEmployeeCity { get { return this.EmployeeCity; } }

        public void TakeLeave(string Reason)
        {
            if (evtleave != null)
            {
                this.evtleave(this.EmployeeID, Reason);
            }
            Console.WriteLine("Employee on leave:" + this.EmployeeID + " , Reason:" + Reason);
        }


    }
}
