﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace console_day_11_linq_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee { EmployeeID = 10001, EmployeeName = "Ram", EmployeeSalary = 30000, EmployeeExp = 5, EmployeeCity = "Guntur" });
            emplist.Add(new Employee { EmployeeID = 10002, EmployeeName = "Raj", EmployeeSalary = 40000, EmployeeExp = 6, EmployeeCity = "Hyderabad" });
            emplist.Add(new Employee { EmployeeID = 10003, EmployeeName = "Krishna", EmployeeSalary = 50000, EmployeeExp = 7, EmployeeCity = "Vizag" });
            emplist.Add(new Employee { EmployeeID = 10004, EmployeeName = "John", EmployeeSalary = 60000, EmployeeExp = 8, EmployeeCity = "Guntur" });
            emplist.Add(new Employee { EmployeeID = 10005, EmployeeName = "Venkat", EmployeeSalary = 70000, EmployeeExp = 9, EmployeeCity = "Hyderabad" });

            List<Leave> leavelist = new List<Leave>();
            leavelist.Add(new Leave { LeaveID = 1, LeaveType = "Sick", Reason = "Not Well", EmployeeID = 10001 });
            leavelist.Add(new Leave { LeaveID = 2, LeaveType = "Personal", Reason = "Marraige", EmployeeID = 10002 });
            leavelist.Add(new Leave { LeaveID = 3, LeaveType = "Holiday", Reason = "Vacation", EmployeeID = 10003 });
            leavelist.Add(new Leave { LeaveID = 4, LeaveType = "Personal", Reason = "Marriage", EmployeeID = 10004 });
            leavelist.Add(new Leave { LeaveID = 5, LeaveType = "Sick", Reason = "Not Well", EmployeeID = 10005 });

            //LINQ
            var count = (from e in emplist
                         where e.EmployeeExp > 5
                         select e).Count();

            Console.WriteLine(count);

            //Lambda
            var count1 = emplist.Count((e) => e.EmployeeExp >5);
            Console.WriteLine(count1);

            //LINQ
            var salary = from e in emplist
                         where e.EmployeeSalary > 50000
                         select new { EID = e.EmployeeID, EName = e.EmployeeName, ESalary = e.EmployeeSalary };
            foreach (var p in salary)
            {
                Console.WriteLine(p.EID + " " + p.EName + " " + p.ESalary);
            }
            //Lambda
            var salary1 = emplist.Where((e) => e.EmployeeSalary > 50000);
            foreach (var p1 in salary1)
            {
                Console.WriteLine(p1.EmployeeID + " " + p1.EmployeeName + " " + p1.EmployeeSalary);
        
            }

            //LINQ
            var datac = from e in emplist
                        where e.EmployeeCity == "Guntur"
                        select new { EID = e.EmployeeID, EName = e.EmployeeName, ECity = e.EmployeeCity };
            foreach (var c in datac)
            {
                Console.WriteLine(c.EID + " " + c.EName + " " + c.ECity);
            }

            //Lambda
            var datac1 = emplist.Where((e) => e.EmployeeCity =="Guntur");
            foreach(var c1 in datac1)
            {
                Console.WriteLine(c1.EmployeeID + " " + c1.EmployeeName + " " + c1.EmployeeCity); ;
            }

            //LINQ
            var datas = from e in emplist
                        where e.EmployeeName.StartsWith("R")
                        select new { EID = e.EmployeeID, EName = e.EmployeeName, EExp = e.EmployeeExp};
            foreach(var n in datas)
            {
                Console.WriteLine(n.EID + " " + n.EName + " " + n.EExp + " ");
            }


            //Lambda
            var datas1 = emplist.Where((e) => e.EmployeeName.StartsWith("R"));
            foreach(var n1 in datas1)
            {
                Console.WriteLine(n1.EmployeeID + " " + n1.EmployeeName + " "+n1.EmployeeExp);
            }


            //LINQ
            var datal = from e in emplist
                        join l in leavelist
                        on e.EmployeeID equals l.EmployeeID
                        select new { EID = e.EmployeeID, EName = e.EmployeeName, LID = l.LeaveID, LType = l.LeaveType, LReason = l.Reason };
            foreach( var t in datal)
            {
                Console.WriteLine(t.EID + " " + t.EName + " " + t.LID + " " + t.LType + " "+t.LReason);
            }
            //Lambda
            var datal1 = emplist.Join(leavelist, (e) => e.EmployeeID, (l) => l.EmployeeID, (e, l) => new {EID=e.EmployeeID,EName=e.EmployeeName,LID=l.LeaveID,Reason=l.Reason });
            foreach (var t1 in datal)
            {
                Console.WriteLine(t1.EID + " " + t1.EName + " " + t1.LID + " " + t1.LReason);
            }

                var group = emplist.GroupBy((g) => g.EmployeeCity).Select((s) => new { City = s.Key, TotalSalary = s.Sum((ss) => ss.EmployeeSalary) });

            Console.ReadLine();
        }
    }
}
