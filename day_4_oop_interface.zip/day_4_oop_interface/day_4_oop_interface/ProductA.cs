﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_oop_interface
{
    class ProductA:IProductTransport
    {
        private int ProductID;
        private string ProductName;

        public ProductA(int ProductID,string ProductName)
        {
            this.ProductID = ProductID;
            this.ProductName = ProductName;

        }
        public int GetPrice()
        {
            return 2000;

        }
        public string GetDetails()
        {
            return this.ProductID + " " + this.ProductName;
        }

        public string GetAddress()
        {
            return "ABC, Pune";
        }
    }
}
