﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win3_dal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter Correct ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_studentid.Text);
                StudentDAL dal = new StudentDAL();
                Student std = dal.Find(id);
                if (std != null)
                {
                    txt_studentname.Text = std.StudentName;
                    txt_studentcity.Text = std.StudentCity;
                    txt_studentaddress.Text = std.StudentAddress;
                    txt_studentemailid.Text = std.StudentEmailID;
                    txt_studentpassword.Text = std.StudentPassword;

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_studentname.Text = string.Empty;
            txt_studentcity.Text = string.Empty;
            txt_studentaddress.Text = string.Empty;
            txt_studentemailid.Text = string.Empty;
            txt_studentpassword.Text = string.Empty;
        }

        private void btn_newstudent_Click(object sender, EventArgs e)
        {
            if (txt_studentname.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");

            }
            else if (txt_studentcity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_studentaddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address");
            }
            else if (txt_studentemailid.Text == string.Empty)
            {
                MessageBox.Show("Enter Email ID");
            }
            else if (txt_studentpassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string name = txt_studentname.Text;
                string city = txt_studentcity.Text;
                string address = txt_studentaddress.Text;
                string emailid = txt_studentemailid.Text;
                string password = txt_studentpassword.Text;
                Student obj = new Student();
                obj.StudentName = name;
                obj.StudentCity = city;
                obj.StudentAddress = address;
                obj.StudentEmailID = emailid;
                obj.StudentPassword = password;

                StudentDAL dal = new StudentDAL();
                int id = dal.AddStudent(obj);
                MessageBox.Show("Student Added" + id);

            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_studentaddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address");
            }
            else
            {
                int ID = Convert.ToInt32(txt_studentid.Text);
                string address = txt_studentaddress.Text;

                StudentDAL dal = new StudentDAL();
                bool status = dal.Update(ID, address);
                if (status)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_studentid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_studentid.Text);
                StudentDAL dal = new StudentDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }

            }
        }
    }
}

