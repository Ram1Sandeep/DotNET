﻿namespace day_9_win2_dal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customercity = new System.Windows.Forms.TextBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customermobileno = new System.Windows.Forms.Label();
            this.lbl_customeremailid = new System.Windows.Forms.Label();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(232, 209);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(149, 26);
            this.txt_customeraddress.TabIndex = 48;
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeraddress.Location = new System.Drawing.Point(29, 209);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(165, 22);
            this.lbl_customeraddress.TabIndex = 47;
            this.lbl_customeraddress.Text = "Customer Address:";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(232, 23);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(149, 26);
            this.txt_customerid.TabIndex = 46;
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(29, 23);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(117, 22);
            this.lbl_customerid.TabIndex = 45;
            this.lbl_customerid.Text = "Customer ID:";
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(460, 222);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(159, 31);
            this.btn_delete.TabIndex = 44;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(460, 136);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(159, 33);
            this.btn_update.TabIndex = 43;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(460, 61);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(159, 30);
            this.btn_find.TabIndex = 42;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(232, 160);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(149, 26);
            this.txt_customerpassword.TabIndex = 41;
            // 
            // txt_customercity
            // 
            this.txt_customercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customercity.Location = new System.Drawing.Point(232, 114);
            this.txt_customercity.Name = "txt_customercity";
            this.txt_customercity.Size = new System.Drawing.Size(149, 26);
            this.txt_customercity.TabIndex = 40;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(232, 65);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(149, 26);
            this.txt_customername.TabIndex = 39;
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(29, 162);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(178, 22);
            this.lbl_customerpassword.TabIndex = 38;
            this.lbl_customerpassword.Text = "Customer Password:";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(29, 116);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(131, 22);
            this.lbl_customercity.TabIndex = 37;
            this.lbl_customercity.Text = "Customer City:";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(29, 65);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(147, 22);
            this.lbl_customername.TabIndex = 36;
            this.lbl_customername.Text = "Customer Name:";
            // 
            // lbl_customermobileno
            // 
            this.lbl_customermobileno.AutoSize = true;
            this.lbl_customermobileno.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customermobileno.Location = new System.Drawing.Point(29, 270);
            this.lbl_customermobileno.Name = "lbl_customermobileno";
            this.lbl_customermobileno.Size = new System.Drawing.Size(186, 22);
            this.lbl_customermobileno.TabIndex = 49;
            this.lbl_customermobileno.Text = "Customer Mobile No:";
            // 
            // lbl_customeremailid
            // 
            this.lbl_customeremailid.AutoSize = true;
            this.lbl_customeremailid.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeremailid.Location = new System.Drawing.Point(29, 327);
            this.lbl_customeremailid.Name = "lbl_customeremailid";
            this.lbl_customeremailid.Size = new System.Drawing.Size(166, 22);
            this.lbl_customeremailid.TabIndex = 50;
            this.lbl_customeremailid.Text = "Customer Email ID:";
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(232, 268);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(149, 26);
            this.txt_customermobileno.TabIndex = 51;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(232, 323);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(149, 26);
            this.txt_customeremailid.TabIndex = 52;
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newcustomer.Location = new System.Drawing.Point(365, 358);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(159, 28);
            this.btn_newcustomer.TabIndex = 53;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(563, 358);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(125, 28);
            this.btn_reset.TabIndex = 54;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 398);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.lbl_customeremailid);
            this.Controls.Add(this.lbl_customermobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customercity);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customercity);
            this.Controls.Add(this.lbl_customername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customercity;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_customercity;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customermobileno;
        private System.Windows.Forms.Label lbl_customeremailid;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.Button btn_reset;
    }
}

