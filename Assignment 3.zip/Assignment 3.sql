create database OnlineFoodorderingDB

use OnlineFoodorderingDB

create table tbl_restaurents
(
restaurentid int identity(100,1) primary key,
restaurentname varchar(100) not null,
restaurentaddress varchar(100) not null,
restaurentcity varchar(100) not null,
contactno varchar(15)
)

insert tbl_restaurents values('Cinnamon','Lakshmipuram','guntur',1234567899)
insert tbl_restaurents values('BBQ','Gardens','guntur',1234567898)
insert tbl_restaurents values('Tomatoes','Arundelpet','Hyderabad',1234567897)
insert tbl_restaurents values('Sankarvilas','Bannerghatta','Bnagalore',1234567896)
insert tbl_restaurents values('Capital','Vidya Nagar','guntur',1234567895)

select * from tbl_restaurents

create table tbl_RMenuItems
(
menuid int identity(1,1) primary key,
restaurentid int not null foreign key references tbl_restaurents(restaurentid),
menuname varchar(100) not null,
menutype varchar(100) not null,
menuprice varchar(100) not null,
menudesc varchar(100) not null
)

insert tbl_RMenuItems values(100,'AB1','nonveg',50,'oil')
insert tbl_RMenuItems values(101,'AB2','veg',150,'oil less')
insert tbl_RMenuItems values(102,'AB3','nonveg',250,'garam')
insert tbl_RMenuItems values(103,'AB4','veg',350,'masala')
insert tbl_RMenuItems values(104,'AB5','nonveg',450,'onions')

select * from tbl_RMenuItems

create  table tbl_customers
(
customerid varchar(100) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customerDOB datetime not null,
customergender varchar(100) not null,
customerpassword varchar(100) not null
)

insert tbl_customers values('a@gmail.com','ram','guntur','05-04-1997','male','123')
insert tbl_customers values('b@gmail.com','sandeep','hyderabad','06-05-1997','female','234')
insert tbl_customers values('c@gmail.com','sai','vizag','07-06-1997','male','345')
insert tbl_customers values('d@gmail.com','kiran','guntur','08-07-1997','female','456')
insert tbl_customers values('e@gmail.com','praveen','bangalore','09-08-1997','male','567')

select * from tbl_customers

create table tbl_orders
(
orderid int identity(1000,1) primary key,
customerid varchar(100) foreign key references tbl_customers(customerid),
orderdate datetime not null,
deliveryaddress varchar(100) not null,
orderstatus varchar(100) not null
)

insert tbl_orders values('a@gmail.com','01-10-2018','srinagar','delivered')
insert tbl_orders values('b@gmail.com','02-09-2018','vidyanagar','not delivered')
insert tbl_orders values('c@gmail.com','03-08-2018','donka road','delivered')
insert tbl_orders values('d@gmail.com','04-07-2018','madhapur','not delivered')
insert tbl_orders values('e@gmail.com','05-06-2018','kukatpally','delivered')

select * from tbl_orders
 
create table tbl_ordermenus
(
orderid int foreign key references tbl_orders(orderid),
menuid int foreign key references tbl_rmenuitems(menuid),
menuqty int not null,
menuprice int not null,
primary key (orderid,menuid)
)

insert tbl_ordermenus values(1000,1,10,5)
insert tbl_ordermenus values(1001,2,20,10)
insert tbl_ordermenus values(1002,3,30,15)
insert tbl_ordermenus values(1003,4,40,20)
insert tbl_ordermenus values(1004,5,50,25)

select * from tbl_ordermenus
select * from tbl_orders
select * from tbl_customers
select * from tbl_RMenuItems
select * from tbl_restaurents

select * from tbl_restaurents where restaurentcity='guntur' 

--1

select r.restaurentid,r.restaurentname,m.menuid,m.menuname,m.menuprice from tbl_restaurents r
join  tbl_RMenuItems m on r.restaurentid=m.restaurentid

--2

select r.restaurentcity, r.restaurentid,r.restaurentname,m.menuid,m.menuname,m.menuprice from tbl_restaurents r
join  tbl_RMenuItems m on r.restaurentid=m.restaurentid where restaurentcity='guntur'

--3

select * from tbl_orders where customerid='a@gmail.com'

--4

select o.orderid,o.customerid,o.orderdate,m.menuid,m.menuqty,m.menuprice from tbl_orders o join tbl_ordermenus m
on o.orderid=m.orderid

--5

select top 5 orderid,customerid from tbl_orders where customerid='a@gmail.com' order by orderdate desc 

--6

select * from tbl_ordermenus order by menuprice asc

--7

select count(restaurentid),restaurentcity from tbl_restaurents group by restaurentcity

--8

select * from tbl_customers where customerid not in (select customerid from tbl_orders)

--9

select top 1 * from tbl_RMenuItems order by menuprice desc

--10

select top 1 * from tbl_RMenuItems where menuprice not in (select top 1 menuprice from tbl_RMenuItems order by menuprice desc)







