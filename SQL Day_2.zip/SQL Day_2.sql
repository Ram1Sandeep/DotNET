create database PathFrontDB2

use PathFrontDB2

create table tbl_customers
(
customerid int identity(1000,1) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customeremail varchar(100) not null unique,
customermobileno varchar(15) not null unique
)

insert tbl_customers values('ram','guntur','123@gmail.com',1234567899)
insert tbl_customers values('sandeep','hyderbad','234@gmail.com',1234567898)
insert tbl_customers values('charan','vizag','345@gmail.com',1234567897)
insert tbl_customers values('varun','guntur','567@gmail.com',1234567896)
insert tbl_customers values('dharam','chennai','678@gmail.com',1234567895)

select * from tbl_customers


create table tbl_items
(
itemid int identity(1,1) primary key,
itemname varchar(100) not null,
itemprice int check(itemprice>0)
)

insert tbl_items values('bisket',10)
insert tbl_items values('chocolate',20)
insert tbl_items values('dairymilk',30)
insert tbl_items values('creambisket',40)
insert tbl_items values('oreo',50)

select * from tbl_items

create table tbl_invoices
(
invoiceid int identity(10000,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
invoicecity varchar(100) not null,
invoicedate datetime not null,
invoiceaddress varchar(100)
)

insert tbl_invoices values(1000,'guntur','01-11-2018','srinagar')
insert tbl_invoices values(1001,'hyderabad','10-11-2018','vidya nagar')
insert tbl_invoices values(1002,'vizag','11-10-2018','krishna nagar')
insert tbl_invoices values(1003,'hyderabad','12-11-2018','arundelpet')
insert tbl_invoices values(1004,'chennai','12-10-2018','aruna nagar')

select * from tbl_invoices


create table tbl_invoiceitems
(
invoiceid int not null foreign key references tbl_invoices(invoiceid),
itemid int not null foreign key references tbl_items(itemid),
itemqty int check(itemqty>0),
itemprice int check (itemprice>0)
primary key (invoiceid,itemid)
)

insert tbl_invoiceitems values(10000,1,10,20)
insert tbl_invoiceitems values(10001,2,20,30)
insert tbl_invoiceitems values(10002,3,20,30)
insert tbl_invoiceitems values(10003,3,20,30)
insert tbl_invoiceitems values(10000,2,10,20)
insert tbl_invoiceitems values(10000,3,10,20)
insert tbl_invoiceitems values(10002,2,20,30)
insert tbl_invoiceitems values(10002,1,20,30)



select * from tbl_invoiceitems

select * from tbl_customers where customerid in (select customerid from tbl_invoiceitems)

select * from tbl_items where itemid not in (select itemid from tbl_invoiceitems)

select * from tbl_customers where customerid in ( select top 1 customerid from tbl_invoices order by invoicedate desc )


create table tbl_Employees
(
employeeid int identity(1000,1) primary key,
employeename varchar(100) not null,
eemployeesalary int not null,
employeedept varchar(100),
Managerid int foreign key references tbl_employees(employeeid)

)

insert tbl_Employees values('john',20000,'HR',null)
insert tbl_Employees values('Rosy',16000,'HR',1011)
insert tbl_Employees values('Raj',20000,'IT',null)
insert tbl_Employees values('Krishna',18000,'IT',1012)

select * from tbl_Employees

select *from tbl_Employees e1 where e1.eemployeesalary>(select avg(e2.eemployeesalary) from tbl_Employees e2
where e2.employeedept=e1.employeedept)

select 2 * from tbl_Employees order by eemployeesalary desc

select *from tbl_customers
select *from tbl_invoices

select tbl_customers.customerid,tbl_customers.customername,tbl_invoices.invoiceid,
tbl_invoices.invoicedate from tbl_customers join tbl_invoices
on
tbl_customers.customerid=tbl_invoices.customerid


select tbl_invoices.invoiceid,tbl_invoices.customerid,tbl_invoices.invoicecity,
tbl_invoiceitems.itemid,tbl_invoiceitems.itemqty,tbl_items.itemname from
tbl_invoices join tbl_invoiceitems
on tbl_invoices.invoiceid=tbl_invoices.invoiceid
join tbl_items
on tbl_invoiceitems.itemid=tbl_items.itemid


select e.employeeid,e.employeename,e.eemployeesalary,e.managerid,m.employeename from tbl_Employees
e left outer join tbl_Employees m
on e.Managerid=m.employeeid

