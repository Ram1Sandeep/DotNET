﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_win_salary_calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getsalary_Click(object sender, EventArgs e)
        {
            if (txt_days.Text == string.Empty)
            {
                MessageBox.Show("Enter Days");

            }
            else if (txt_perdaysalary.Text == string.Empty) 
            {
                MessageBox.Show("Enter Per Day Salary");
            }
            else
            {
                int days = Convert.ToInt32(txt_days.Text);
                int perdaysalary = Convert.ToInt32(txt_perdaysalary.Text);

                day_5_salary_library.Salary obj = new day_5_salary_library.Salary();
                int total = obj.GetSalary(days, perdaysalary);
                lbl_salary.Text = total.ToString();
            }
        }
    }
}
