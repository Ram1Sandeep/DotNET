﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace mvc_model.Models
{
    public class StudentModel
    {
        [Display(Name ="Student ID :")]
        public int StudentID { get; set; }

        [Display(Name = "Student Name :")]
        [Required(ErrorMessage = "*")]
        [StringLength(100,MinimumLength =5,ErrorMessage ="Invalid Name")]
        public string StudentName { get; set; }

        [Display(Name = "Student Email :")]
        [Required(ErrorMessage = "*")]
        [EmailAddress(ErrorMessage = "Invalid Format")]
        public string StudentEmailID { get; set; }

        [Display(Name = "Student Password :")]
        [Required(ErrorMessage = "*")]
        public string StudentPassword { get; set; }

        [Display(Name = "Student Mobile No :")]
        [Required(ErrorMessage = "*")]
        [RegularExpression("^[7-9][0-9]{9}$",ErrorMessage="Invalid Format")]
        public string StudentMobileNo { get; set; }


        [Display(Name = "Student City :")]
        [Required(ErrorMessage = "*")]
        public string StudentCity { get; set; }

        [Display(Name = "Student Gender :")]
        [Required(ErrorMessage = "*")]
        public string StudentGender { get; set; }

        [Display(Name ="Student Marks :")]
        [Required(ErrorMessage = "*")]
        [Range(40,100,ErrorMessage ="Invalid Marks")]
        public int StudentAvgMarks { get; set; }

        [Display(Name = "Student Image :")]
        
        public string StudentImageAddress { get; set; }


    }
}