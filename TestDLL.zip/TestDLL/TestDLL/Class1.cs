﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDLL
{
    public class Class1
    {
        public string Call1()
        {
            return "Hello from Call1";
        }
        public string Call2()
        {
            return "Hello from Call2";
        }
    }
}
