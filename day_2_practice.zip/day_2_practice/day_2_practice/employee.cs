﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_practice
{
    class employee

    {
        private int employeeid;
        private string employeename;
        private string employeecity;
        private double employeesalary;

        public employee(int employeeid, string employeename, string employeecity,double employeesalary)
        {
            this.employeeid = employeeid;
            this.employeename = employeename;
            this.employeecity = employeecity;
            this.employeesalary = employeesalary;


        }
        public double getemployeesalary(int noofdays)
        {
            double d = employeesalary / 30;
            return noofdays * d;

        }
        public string getdetails()
        {
            return this.employeeid + " " + this.employeename + " " + this.employeecity + " " + this.employeesalary + " ";

        }






    }

}
