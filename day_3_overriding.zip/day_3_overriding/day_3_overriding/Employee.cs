﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_3_overriding
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private int EmployeeSalary;
        public Employee(int EmployeeID,string EmployeeName,int EmployeeSalary)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeSalary = EmployeeSalary;

        }

        public int PEmployeeID
        {
            get
            {
                return this.EmployeeID;
            }
        }

        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public int PEmployeeSalary
        {
            get
            {
                return this.EmployeeSalary;
            }
        }
        public string GetWork()
        {
            return "Developing.Net Application";
        }
        public virtual int GetSalary(int Days)
        {
            int Bonus = 2000;
            int TDS = 1000;
            int Salary = (this.EmployeeSalary / 30 * Days) + Bonus-TDS;
            return Salary;

        }
    }
    
}
