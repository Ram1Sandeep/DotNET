﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;


namespace Win_MiniProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                MessageBox.Show("Enter Login ID");
            }
            else if (txt_password.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");

            }
            else
            {
                BankDAL dal = new BankDAL();
                bool status = dal.LoginCustomer(Convert.ToInt32(txt_loginid.Text), txt_password.Text);

                if (status)
                {
                    Test.cid = Convert.ToInt32(txt_loginid.Text);
                    frm_home f = new frm_home();
                    f.Show();
                }
                else
                {
                    MessageBox.Show("invalid");
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
                   }

        private void btn_reset_Click_1(object sender, EventArgs e)
        {
            txt_loginid.Text = string.Empty;
            txt_password.Text = string.Empty;
        }

        private void btn_resetnew_Click(object sender, EventArgs e)
        {
            txt_Customeremail.Text = string.Empty;
            txt_customermobile.Text = string.Empty;
            txt_Customername.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;
            rdb_female.Checked = false;
            rdb_male.Checked = false;

        }

        private void btn_newcustomer_Click_1(object sender, EventArgs e)
        {
            if (txt_Customername.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if (txt_Customeremail.Text == string.Empty)
            {
                MessageBox.Show("Enter Email");
            }
            else if (txt_customermobile.Text == string.Empty)
            {
                MessageBox.Show("Enter Mobile");
            }
            else if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                MessageBox.Show("Enter Gender");
            }
            else if (txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {

                BankDAL dal = new BankDAL();
                Customer c = new Customer();
                c.CustomerName = txt_Customername.Text;
                c.CustomerEmail = txt_Customeremail.Text;
                c.CustomerMobile = txt_customermobile.Text;
                if (rdb_male.Checked == true)
                {
                    c.CustomerGender = "Male";
                }
                else
                {
                    c.CustomerGender = "Female";
                }
                c.CustomerPassword = txt_customerpassword.Text;

                int id = dal.AddCustomer(c);
                MessageBox.Show("Customer ID is " + id);

            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
