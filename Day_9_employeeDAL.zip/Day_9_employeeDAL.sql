select * from tbl_employees
sp_help tbl_employees


create proc proc_addemployee(@name varchar(100),@city varchar(100),@password varchar(100))
as
insert tbl_employees values(@name,@city,@password,GETDATE())
return @@identity
--2


create proc proc_employeedetails(@id int)
as
select * from tbl_employees where EmployeeID=@id
--3


create proc proc_showemployees(@city varchar(100))
as
select * from tbl_employees where EmployeeCity=@city
--4


create proc proc_searchemployees(@key varchar(100))
as
select * from tbl_employees where
EmployeeID like '%'+@key+'%'or EmployeeName like '%'+@key+'%' or EmployeeCity like '%'+@key+'%';
--5


create proc proc_updateemployee(@id int,@city varchar(100),@password varchar(100))
as
update tbl_employees set EmployeeCity=@city,EmployeePassword=@password where EmployeeID=@id
return @@rowcount
--6

create proc proc_deleteemployee(@id int)
as
delete tbl_employees where EmployeeID=@id
return @@rowcount
--7


create proc proc_login(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_employees where 
EmployeeID=@id and EmployeePassword=@password
return @count 
--8



select* from tbl_students










create proc proc_addcustomer(@name varchar(100),@city varchar(100),@password varchar(100),@address varchar(100),@mobileno varchar(100),@emailid varchar(100))
as
insert tbl_customers values(@name,@city,@password,@address,@mobileno,@emailid)
return @@identity
--2


create proc proc_customerdetails(@id int)
as
select * from tbl_customers where CustomerID=@id
--3


create proc proc_showcustomers(@city varchar(100))
as
select * from tbl_customers where CustomerCity=@city
--4


create proc proc_searchcustomers(@key varchar(100))
as
select * from tbl_customers where
CustomerID like '%'+@key+'%'or CustomerName like '%'+@key+'%' or CustomerCity like '%'+@key+'%'or CustomerAddress like '%'+@key+'%'or CustomerMobileNo like '%'+@key+'%'or CustomerEmailID like '%'+@key+'%';
--5


create proc proc_updatecustomer(@id int,@address varchar(100),@mobileno varchar(100))
as
update tbl_customers set CustomerAddress=@address,CustomerMobileNo=@mobileno where CustomerID=@id
return @@rowcount
--6

create proc proc_deletecustomer(@id int)
as
delete tbl_customers where CustomerID=@id
return @@rowcount
--7


create proc proc_login2(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_customers where 
CustomerID=@id and CustomerPassword=@password
return @count 
--8

SP_help tbl_customers

select * from tbl_customers

alter table tbl_customers

create proc proc_addstudent(@name varchar(100),@city varchar(100),@password varchar(100),@address varchar(100),@emailid varchar(100))
as
insert tbl_students values(@name,@city,@password,@address,@emailid)
return @@identity
--2


create proc proc_studentsdetails(@id int)
as
select * from tbl_students where StudentID=@id
--3


create proc proc_showstudents(@city varchar(100))
as
select * from tbl_students where StudentCity=@city
--4


create proc proc_searchstudents(@key varchar(100))
as
select * from tbl_students where
StudentID like '%'+@key+'%'or StudentName like '%'+@key+'%' or StudentCity like '%'+@key+'%';
--5


create proc proc_updatestudents(@id int,@city varchar(100),@password varchar(100))
as
update tbl_students set StudentCity=@city,StudentPassword=@password where StudentID=@id
return @@rowcount
--6

create proc proc_deletestudents(@id int)
as
delete tbl_employees where EmployeeID=@id
return @@rowcount
--7


create proc proc_login3(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_students where 
StudentID=@id and StudentPassword=@password
return @count 
--8


