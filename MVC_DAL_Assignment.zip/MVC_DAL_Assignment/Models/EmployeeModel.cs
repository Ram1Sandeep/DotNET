﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_DAL_Assignment.Models
{
    public class EmployeeModel
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeCity { get; set; }
        public string EmployeeEmailID { get; set; }

    }
}