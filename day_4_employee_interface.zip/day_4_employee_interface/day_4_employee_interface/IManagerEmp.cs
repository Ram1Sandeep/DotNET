﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    interface IManagerEmp
    {
        int GetEmployeeID();
        int GetEmployeeExp();
        string GetEmployeeProjectDetails();
    }
}
