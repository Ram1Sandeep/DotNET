﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win2_dal
{
    public partial class frm_Show_Customers : Form
    {
        public frm_Show_Customers()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string city = txt_city.Text;
            List<Customer> list = dal.ShowCustomer(city);
            dg_customers.DataSource = list;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            string Key = txt_search.Text;
            List<Customer> list = dal.SearchCustomer(Key);
            dg_customers.DataSource = list;
        }
    }
}
