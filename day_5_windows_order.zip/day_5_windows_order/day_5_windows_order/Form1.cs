﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_windows_order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void cmb_ordercity_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }


        private void btn_place_Click(object sender, EventArgs e)
        {

            if (txt_orderid.Text == string.Empty)
            {
                MessageBox.Show("Enter Order ID");
            }

            else if (txt_cname.Text == string.Empty)
            {
                MessageBox.Show("Enter Customer Name");
            }
            else if (txt_itemid.Text == string.Empty)
            {
                MessageBox.Show("Enter Item ID");
            }
            else if (txt_itemqty.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Qty");
            }
            else if (txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("Enter Item Price");
            }
            else if (txt_DAddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Delivery Address");
            }
            else if (rdb_cod.Checked == false && rdb_paytm.Checked == false)
            {
                MessageBox.Show("Select your Payment");
            }
            else
            {
                string payment = string.Empty;
                if (rdb_cod.Checked)
                {
                    payment = "COD";

                }
                else
                {
                    payment = "Paytm";
                }
            
                int id = Convert.ToInt32(txt_orderid.Text);
                string custname = txt_cname.Text;
                int itemid = Convert.ToInt32(txt_itemid.Text);
                int itemqty = Convert.ToInt32(txt_itemqty.Text);
                int itemprice = Convert.ToInt32(txt_itemprice.Text);
                string delivery = txt_DAddress.Text;

                Order obj = new Order(id, custname, itemid, itemqty, itemprice, delivery);
                MessageBox.Show(obj.GetOrderValue().ToString());
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_ordercity.Items.Add("PUNE");
            cmb_ordercity.Items.Add("CHENNAI");
            cmb_ordercity.Items.Add("HYDERABAD");
        }
    }
}