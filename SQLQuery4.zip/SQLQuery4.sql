create proc add_data_t1(@code int,@name varchar(10))
as
begin
insert t1 values(@code,@name);
return 0;
end

exec add_data_t1 12,'abc'

select * from t1

----1

create proc add_data_t3
as 
update t1
set  name='def'
where code=1
exec  add_data_t3

select * from t1

----2

create proc p_cus1(@customerid int,@customercity varchar(100),@customermobileno varchar(100))
as
update tbl_customers set customermobileno=@customermobileno
where @customercity=@customercity and customerid=@customerid

exec p_cus1 1000,'guntur','1234569879'

select * from tbl_customers


-----3


