﻿namespace day_9_win3_dal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_newstudent = new System.Windows.Forms.Button();
            this.txt_studentemailid = new System.Windows.Forms.TextBox();
            this.lbl_studentemailid = new System.Windows.Forms.Label();
            this.txt_studentaddress = new System.Windows.Forms.TextBox();
            this.lbl_customeraddress = new System.Windows.Forms.Label();
            this.txt_studentid = new System.Windows.Forms.TextBox();
            this.lbl_studentid = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_studentcity = new System.Windows.Forms.TextBox();
            this.txt_studentname = new System.Windows.Forms.TextBox();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            this.lbl_studentname = new System.Windows.Forms.Label();
            this.txt_studentpassword = new System.Windows.Forms.TextBox();
            this.lbl_studentpassword = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(598, 356);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(125, 28);
            this.btn_reset.TabIndex = 73;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_newstudent
            // 
            this.btn_newstudent.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newstudent.Location = new System.Drawing.Point(410, 356);
            this.btn_newstudent.Name = "btn_newstudent";
            this.btn_newstudent.Size = new System.Drawing.Size(159, 28);
            this.btn_newstudent.TabIndex = 72;
            this.btn_newstudent.Text = "New Customer";
            this.btn_newstudent.UseVisualStyleBackColor = true;
            this.btn_newstudent.Click += new System.EventHandler(this.btn_newstudent_Click);
            // 
            // txt_studentemailid
            // 
            this.txt_studentemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentemailid.Location = new System.Drawing.Point(220, 288);
            this.txt_studentemailid.Name = "txt_studentemailid";
            this.txt_studentemailid.Size = new System.Drawing.Size(149, 26);
            this.txt_studentemailid.TabIndex = 71;
            // 
            // lbl_studentemailid
            // 
            this.lbl_studentemailid.AutoSize = true;
            this.lbl_studentemailid.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentemailid.Location = new System.Drawing.Point(17, 288);
            this.lbl_studentemailid.Name = "lbl_studentemailid";
            this.lbl_studentemailid.Size = new System.Drawing.Size(151, 22);
            this.lbl_studentemailid.TabIndex = 69;
            this.lbl_studentemailid.Text = "Student Email ID:";
            this.lbl_studentemailid.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_studentaddress
            // 
            this.txt_studentaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentaddress.Location = new System.Drawing.Point(220, 207);
            this.txt_studentaddress.Name = "txt_studentaddress";
            this.txt_studentaddress.Size = new System.Drawing.Size(149, 26);
            this.txt_studentaddress.TabIndex = 67;
            // 
            // lbl_customeraddress
            // 
            this.lbl_customeraddress.AutoSize = true;
            this.lbl_customeraddress.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customeraddress.Location = new System.Drawing.Point(17, 209);
            this.lbl_customeraddress.Name = "lbl_customeraddress";
            this.lbl_customeraddress.Size = new System.Drawing.Size(150, 22);
            this.lbl_customeraddress.TabIndex = 66;
            this.lbl_customeraddress.Text = "Student Address:";
            // 
            // txt_studentid
            // 
            this.txt_studentid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentid.Location = new System.Drawing.Point(220, 23);
            this.txt_studentid.Name = "txt_studentid";
            this.txt_studentid.Size = new System.Drawing.Size(149, 26);
            this.txt_studentid.TabIndex = 65;
            // 
            // lbl_studentid
            // 
            this.lbl_studentid.AutoSize = true;
            this.lbl_studentid.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentid.Location = new System.Drawing.Point(17, 23);
            this.lbl_studentid.Name = "lbl_studentid";
            this.lbl_studentid.Size = new System.Drawing.Size(102, 22);
            this.lbl_studentid.TabIndex = 64;
            this.lbl_studentid.Text = "Student ID:";
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(448, 222);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(159, 31);
            this.btn_delete.TabIndex = 63;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(448, 136);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(159, 33);
            this.btn_update.TabIndex = 62;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(448, 61);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(159, 30);
            this.btn_find.TabIndex = 61;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_studentcity
            // 
            this.txt_studentcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentcity.Location = new System.Drawing.Point(220, 114);
            this.txt_studentcity.Name = "txt_studentcity";
            this.txt_studentcity.Size = new System.Drawing.Size(149, 26);
            this.txt_studentcity.TabIndex = 59;
            // 
            // txt_studentname
            // 
            this.txt_studentname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentname.Location = new System.Drawing.Point(220, 65);
            this.txt_studentname.Name = "txt_studentname";
            this.txt_studentname.Size = new System.Drawing.Size(149, 26);
            this.txt_studentname.TabIndex = 58;
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentcity.Location = new System.Drawing.Point(17, 116);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(116, 22);
            this.lbl_studentcity.TabIndex = 56;
            this.lbl_studentcity.Text = "Student City:";
            // 
            // lbl_studentname
            // 
            this.lbl_studentname.AutoSize = true;
            this.lbl_studentname.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentname.Location = new System.Drawing.Point(17, 65);
            this.lbl_studentname.Name = "lbl_studentname";
            this.lbl_studentname.Size = new System.Drawing.Size(132, 22);
            this.lbl_studentname.TabIndex = 55;
            this.lbl_studentname.Text = "Student Name:";
            // 
            // txt_studentpassword
            // 
            this.txt_studentpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_studentpassword.Location = new System.Drawing.Point(220, 358);
            this.txt_studentpassword.Name = "txt_studentpassword";
            this.txt_studentpassword.Size = new System.Drawing.Size(149, 26);
            this.txt_studentpassword.TabIndex = 75;
            // 
            // lbl_studentpassword
            // 
            this.lbl_studentpassword.AutoSize = true;
            this.lbl_studentpassword.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentpassword.Location = new System.Drawing.Point(12, 358);
            this.lbl_studentpassword.Name = "lbl_studentpassword";
            this.lbl_studentpassword.Size = new System.Drawing.Size(163, 22);
            this.lbl_studentpassword.TabIndex = 74;
            this.lbl_studentpassword.Text = "Student Password:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(735, 424);
            this.Controls.Add(this.txt_studentpassword);
            this.Controls.Add(this.lbl_studentpassword);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_newstudent);
            this.Controls.Add(this.txt_studentemailid);
            this.Controls.Add(this.lbl_studentemailid);
            this.Controls.Add(this.txt_studentaddress);
            this.Controls.Add(this.lbl_customeraddress);
            this.Controls.Add(this.txt_studentid);
            this.Controls.Add(this.lbl_studentid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_studentcity);
            this.Controls.Add(this.txt_studentname);
            this.Controls.Add(this.lbl_studentcity);
            this.Controls.Add(this.lbl_studentname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_newstudent;
        private System.Windows.Forms.TextBox txt_studentemailid;
        private System.Windows.Forms.Label lbl_studentemailid;
        private System.Windows.Forms.TextBox txt_studentaddress;
        private System.Windows.Forms.Label lbl_customeraddress;
        private System.Windows.Forms.TextBox txt_studentid;
        private System.Windows.Forms.Label lbl_studentid;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_studentcity;
        private System.Windows.Forms.TextBox txt_studentname;
        private System.Windows.Forms.Label lbl_studentcity;
        private System.Windows.Forms.Label lbl_studentname;
        private System.Windows.Forms.TextBox txt_studentpassword;
        private System.Windows.Forms.Label lbl_studentpassword;
    }
}

