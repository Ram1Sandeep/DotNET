﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_win_calculation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_sum_Click(object sender, EventArgs e)
        {
            if (txt_num1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");

            }
            else if (txt_num2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_num1.Text);
                int num2 = Convert.ToInt32(txt_num2.Text);

                day_5_library_calc_assignment.Library obj = new day_5_library_calc_assignment.Library();
                int total = obj.GetSum(num1, num2);
                lbl_sum.Text = total.ToString();
            }

        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            if (txt_num1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");

            }
            else if (txt_num2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_num1.Text);
                int num2 = Convert.ToInt32(txt_num2.Text);

                day_5_library_calc_assignment.Library obj = new day_5_library_calc_assignment.Library();
                int total2 = obj.GetMultiply(num1, num2);
                lbl_multiply.Text = total2.ToString();

            }
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            if (txt_num1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");

            }
            else if (txt_num2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_num1.Text);
                int num2 = Convert.ToInt32(txt_num2.Text);

                day_5_library_calc_assignment.Library obj = new day_5_library_calc_assignment.Library();
                float total3 = obj.GetDivide(num1, num2);
                lbl_divide.Text = total3.ToString();
            }
        }

        private void btn_subtract_Click(object sender, EventArgs e)
        {
            if (txt_num1.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 1");

            }
            else if (txt_num2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_num1.Text);
                int num2 = Convert.ToInt32(txt_num2.Text);

                day_5_library_calc_assignment.Library obj = new day_5_library_calc_assignment.Library();
                int total4 = obj.GetSubtract(num1, num2);
                lbl_subtract.Text = total4.ToString();



            }
        }
    }
}
