﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_callbyvalue_callbyref
{
    partial class ABC
    {
        public void Call()
        {

        }
    }
}
