﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_employeename.Text =string.Empty;
            txt_employeecity.Text = string.Empty;
            txt_employeepassword.Text = string.Empty;

        }

        private void btn_newemployee_Click(object sender, EventArgs e)
        {
            if(txt_employeename.Text==string.Empty)
            {
                MessageBox.Show("Enter Name");

            }
            else if(txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_employeepassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string name = txt_employeename.Text;
                string city = txt_employeecity.Text;
                string password = txt_employeepassword.Text;
                Employee obj = new Employee();
                obj.EmployeeName = name;
                obj.EmployeeCity = city;
                obj.EmployeePassword = password;

                EmployeeDAL dal = new EmployeeDAL();
                int id = dal.AddEmployee(obj);
                MessageBox.Show("Employee Added" + id);

            }
        }
    }
}
