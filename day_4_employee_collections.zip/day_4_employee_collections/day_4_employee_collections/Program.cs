﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_collections
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company(1, "PathFront");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter Your Operation: 1.Add, 2.Find, 3.Remove, 4.Show, 5.Exit 6.Leave");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("Enter Employee Name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter Employee City:");
                        string city = Console.ReadLine();
                        Employee e = new Employee(name, city);
                        c.AddEmployee(e);
                        Console.WriteLine("Employee Added:" + e.PEmployeeID);
                        break;
                    case 2:
                        Console.WriteLine("Enter EmployeeID:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Employee obj = c.Find(ID);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PEmployeeID + " " + obj.PEmployeeName);

                        }
                        else
                        {
                            Console.WriteLine("Employee not Found");

                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Employee ID");
                        int EID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(EID);
                        if (status)
                        {
                            Console.WriteLine("Employee Removed");
                        }
                        else
                        {
                            Console.WriteLine("Employee Not Found");

                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = true;
                        break;
                    case 6:
                        Console.WriteLine("Enter Employee ID:");
                        int EmployeeID = Convert.ToInt32(Console.ReadLine());
                        Employee Eobj = c.Find(EmployeeID);
                        Console.WriteLine("Enter Reason:");
                        string Reason = Console.ReadLine();
                        Eobj.TakeLeave(Reason);
                        break;

                }
            }
        }
    }
}
