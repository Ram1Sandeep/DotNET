﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_9_console_delegate
{
    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();

            int a = 100;

            Test.del d = new Test.del(obj.call1);

            d += new Test.del(obj.call2);
            d -= new Test.del(obj.call1);
            d += new Test.del(obj.call1);

            d += delegate (string s)
              {
                  Console.WriteLine("anonymous function:" + s+" "+a);
              };

            d += (s) => Console.WriteLine(s);//lambda expression

            d("Hello Delegate");

            Console.ReadLine();
        }
    }
}
