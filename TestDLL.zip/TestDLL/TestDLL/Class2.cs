﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDLL
{
  public  class Class2

    {
        public string Call3()
        {
            return "Hello from Call3";
        }
        public string Call4()
        {
            return "Hello from Call4";
        }
    }
}
