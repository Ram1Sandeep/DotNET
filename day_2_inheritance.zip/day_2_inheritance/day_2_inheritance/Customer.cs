﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_inheritance
{
    class Customer
    {
        public string CustomerEmailID;
        private string CustomerName;

        public Customer(string CustomerEmailID,string CustomerName)
        {
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerName = CustomerName;

        }

        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;

            }
        }
        public string PCustomerName
        {
            get
            {
                return CustomerName;
            }
        }
    }
}
