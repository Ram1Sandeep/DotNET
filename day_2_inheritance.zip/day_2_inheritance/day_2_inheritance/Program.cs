﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter customer emailid");
            string email = Console.ReadLine();
            Console.Write("enter customer name");
            string name = Console.ReadLine();

            Console.WriteLine("enter customer type");
            string type = Console.ReadLine();
            if (type == "online")
            {
                Console.WriteLine("enter payment type");
                string PaymentType = Console.ReadLine();
                Console.WriteLine("enter delivery address");
                string DeliveryAddress = Console.ReadLine();
                Customer_online obj_online = new Customer_online(email, name, PaymentType, DeliveryAddress);
                Console.WriteLine(obj_online.PCustomerEmailID + " " + obj_online.PCustomerName + " " + obj_online.PPaymentType + " " + obj_online.PDeliveryAddress);

            }
            else
            {




                Customer obj = new Customer(email, name);
                Console.WriteLine(obj.PCustomerEmailID + " " + obj.PCustomerName);
            }
            Console.ReadLine();




        }
    }
}
