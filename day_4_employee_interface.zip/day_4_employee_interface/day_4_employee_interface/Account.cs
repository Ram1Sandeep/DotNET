﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    class Account
    {
        public void GetEmployee(IAccountEmp e)
        {
            int Salary = e.GetEmployeeSalary();
            Console.WriteLine("Employee Salary" + Salary);
            int account = e.GetEmployeeAccountNo();
            Console.WriteLine("Employee Account Number" + account);
            int ID = e.GetEmployeeID();
            Console.WriteLine("Employee ID" + ID);

        }
    }
}
