﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_generics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int>();
            marks.Add(100);
            marks.Add(200);
            int m = marks[0];
             foreach(int mm in marks)
            {
                Console.WriteLine(mm);
            }
            List<string> names = new List<string>();
            names.Add("A");
            names.Add("B");

            foreach (string n in names)
            {
                Console.WriteLine(n);
            }

            Dictionary<int, string> nameswithkeys = new Dictionary<int, string>();
            nameswithkeys.Add(1001, "ABC");
            nameswithkeys.Add(1002, "DEF");

            string s1 = nameswithkeys[1001];
            Console.WriteLine(s1);

            Test t= new Test();
            int a = t.GetDetails<int>(1000);
            string str = t.GetDetails<string>("ABC");
            Console.WriteLine(a);
            Console.Write(str);
            Console.ReadLine();
        }
    }
}
