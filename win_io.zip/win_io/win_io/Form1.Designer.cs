﻿namespace win_io
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_binary_writer = new System.Windows.Forms.Button();
            this.btn_binary_reader = new System.Windows.Forms.Button();
            this.btn_stream_reader = new System.Windows.Forms.Button();
            this.btn_stream_writer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_binary_writer
            // 
            this.btn_binary_writer.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_binary_writer.Location = new System.Drawing.Point(31, 62);
            this.btn_binary_writer.Name = "btn_binary_writer";
            this.btn_binary_writer.Size = new System.Drawing.Size(193, 51);
            this.btn_binary_writer.TabIndex = 0;
            this.btn_binary_writer.Text = "Binary Writer";
            this.btn_binary_writer.UseVisualStyleBackColor = true;
            this.btn_binary_writer.Click += new System.EventHandler(this.btn_binary_writer_Click);
            // 
            // btn_binary_reader
            // 
            this.btn_binary_reader.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_binary_reader.Location = new System.Drawing.Point(270, 62);
            this.btn_binary_reader.Name = "btn_binary_reader";
            this.btn_binary_reader.Size = new System.Drawing.Size(209, 51);
            this.btn_binary_reader.TabIndex = 1;
            this.btn_binary_reader.Text = "Binary Reader";
            this.btn_binary_reader.UseVisualStyleBackColor = true;
            this.btn_binary_reader.Click += new System.EventHandler(this.btn_binary_reader_Click);
            // 
            // btn_stream_reader
            // 
            this.btn_stream_reader.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stream_reader.Location = new System.Drawing.Point(270, 191);
            this.btn_stream_reader.Name = "btn_stream_reader";
            this.btn_stream_reader.Size = new System.Drawing.Size(209, 51);
            this.btn_stream_reader.TabIndex = 3;
            this.btn_stream_reader.Text = "Stream Reader";
            this.btn_stream_reader.UseVisualStyleBackColor = true;
            this.btn_stream_reader.Click += new System.EventHandler(this.btn_stream_reader_Click);
            // 
            // btn_stream_writer
            // 
            this.btn_stream_writer.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stream_writer.Location = new System.Drawing.Point(31, 191);
            this.btn_stream_writer.Name = "btn_stream_writer";
            this.btn_stream_writer.Size = new System.Drawing.Size(193, 51);
            this.btn_stream_writer.TabIndex = 2;
            this.btn_stream_writer.Text = "Stream Writer";
            this.btn_stream_writer.UseVisualStyleBackColor = true;
            this.btn_stream_writer.Click += new System.EventHandler(this.btn_stream_writer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 320);
            this.Controls.Add(this.btn_stream_reader);
            this.Controls.Add(this.btn_stream_writer);
            this.Controls.Add(this.btn_binary_reader);
            this.Controls.Add(this.btn_binary_writer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_binary_writer;
        private System.Windows.Forms.Button btn_binary_reader;
        private System.Windows.Forms.Button btn_stream_reader;
        private System.Windows.Forms.Button btn_stream_writer;
    }
}

