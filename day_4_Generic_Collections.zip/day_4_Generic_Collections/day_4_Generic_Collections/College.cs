﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_Generic_Collections
{
    class College
    {
        public void onleave(int id,string reason)
        {
            Console.WriteLine("college class : student on leave:" + id + "," + reason);
        }
        private int CollegeID;
        private string CollegeName;

        public College(int CollegeID, string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;

        }
        private List<Student> studentlist = new List<Student>();

        public void AddStudent(Student st)
        {
            Student.delleave d = new Student.delleave(this.onleave);

            st.evtleave += d;
            studentlist.Add(st);
        }
        public Student Find(int ID)
        {
            foreach(Student s in studentlist)
            {
                if (s.PStudentID==ID)
                {
                    return s;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach(Student s in studentlist)
            {
                if (s.PStudentID==ID)
                {
                    studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach(Student s in studentlist)
            {

                Console.WriteLine(s.PStudentID + " " + s.PStudentName + " " + s.PStudentCity);
            }

        }
    }
}
