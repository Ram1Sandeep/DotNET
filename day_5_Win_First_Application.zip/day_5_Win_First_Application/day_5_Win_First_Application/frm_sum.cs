﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_Win_First_Application
{
    public partial class frm_sum : Form
    {
        public frm_sum()
        {
            InitializeComponent();
        }
        private void btn_sum_Click(object sender, EventArgs e)
        {
            if(txt_number1.Text==string.Empty)
            {
                MessageBox.Show("Enter Number 1");
            }
            else if(txt_number2.Text == string.Empty)
            {
                MessageBox.Show("Enter Number 2");
            }
            else
            {
                int num1 = Convert.ToInt32(txt_number1.Text);
                int num2 = Convert.ToInt32(txt_number2.Text);
                int total = num1 + num2;
                MessageBox.Show("total" + total);
                
            }
        }
    }
}
