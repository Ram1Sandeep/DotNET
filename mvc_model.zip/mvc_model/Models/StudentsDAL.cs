﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace mvc_model.Models
{
    public class StudentsDAL
    {
        SqlConnection con =new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddStudent(StudentModel model)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_add_student", con);
                com_add.Parameters.AddWithValue("@name", model.StudentName);
                com_add.Parameters.AddWithValue("@email", model.StudentEmailID);
                com_add.Parameters.AddWithValue("@pass", model.StudentPassword);
                com_add.Parameters.AddWithValue("@mobileno", model.StudentMobileNo);
                com_add.Parameters.AddWithValue("@city", model.StudentCity);
                com_add.Parameters.AddWithValue("@gender", model.StudentGender);
                com_add.Parameters.AddWithValue("@avgmarks", model.StudentAvgMarks);
                com_add.Parameters.AddWithValue("@image", model.StudentImageAddress);
                com_add.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_add.Parameters.Add(retdata);
                con.Open();
                com_add.ExecuteNonQuery();

                int ID = Convert.ToInt32(retdata.Value);

                con.Close();
                return ID;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public StudentModel Find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findstudent", con);
                com_find.Parameters.AddWithValue("@id", id);
                com_find.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader rd = com_find.ExecuteReader();
                StudentModel m = new StudentModel();

                if (rd.Read())
                {
                    m.StudentID = rd.GetInt32(0);
                    m.StudentName = rd.GetString(1);
                    m.StudentEmailID = rd.GetString(2);
                    m.StudentPassword = rd.GetString(3);
                    m.StudentMobileNo = rd.GetString(4);
                    m.StudentCity = rd.GetString(5);
                    m.StudentGender = rd.GetString(6);
                    m.StudentAvgMarks = rd.GetInt32(7);
                    m.StudentImageAddress = rd.GetString(8);
                }
                con.Close();
                if (rd != null)
                {
                    return m;
                }
                else
                {
                    return null;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

            public List<StudentModel> SearchStudent(string key)
          {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findstudent", con);
                com_find.Parameters.AddWithValue("@id", key);
                com_find.CommandType = CommandType.StoredProcedure;
                List<StudentModel> list = new List<StudentModel>();
                con.Open();
                SqlDataReader rd = com_find.ExecuteReader();

                while (rd.Read())
                {
                    StudentModel m = new StudentModel();
                    m.StudentID = rd.GetInt32(0);
                    m.StudentName = rd.GetString(1);
                    m.StudentEmailID = rd.GetString(2);
                    m.StudentPassword = rd.GetString(3);
                    m.StudentMobileNo = rd.GetString(4);
                    m.StudentCity = rd.GetString(5);
                    m.StudentGender = rd.GetString(6);
                    m.StudentAvgMarks = rd.GetInt32(7);
                    m.StudentImageAddress = rd.GetString(8);
                    list.Add(m);

                }
                con.Close();
                if (rd != null)
                {
                    return list;
                }
                else
                {
                    return null;
                }


            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Delete(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletestudent", con);
                com_delete.Parameters.AddWithValue("@id", id);
                com_delete.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_delete.Parameters.Add(retdata);
                com_delete.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool update(int id, string pass, string mobileno)
        {
            try
            {
                SqlCommand com_update = new SqlCommand("proc_updatestudent", con);
                com_update.Parameters.AddWithValue("@id", id);
                com_update.Parameters.AddWithValue("@password", pass);
                com_update.Parameters.AddWithValue("@mobileno", mobileno);
                com_update.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_update.Parameters.Add(retdata);
                com_update.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

             public bool login(string id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@password", password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;
                con.Open();
                com_login.Parameters.Add(retdata);
                com_login.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

    }

}
