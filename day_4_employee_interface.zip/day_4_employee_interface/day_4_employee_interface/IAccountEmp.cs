﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    interface IAccountEmp
    {
        int GetEmployeeSalary();
        int GetEmployeeAccountNo();

        int GetEmployeeID();
    }
}
