﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_generics
{
    class Test
    {
        public T GetDetails<T>(T Para)
        {
            return Para;
        }
    }
}
