﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace mvc_model.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage ="*")]
        [Display(Name ="Login ID :")]

        public string LoginID { get; set; }

        [Required(ErrorMessage = "*")]
        [Display(Name = "Password :")]
        [DataType(DataType.Password)]

        public string Password { get; set; }




    }
}