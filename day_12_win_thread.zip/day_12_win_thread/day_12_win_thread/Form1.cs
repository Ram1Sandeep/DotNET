﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace day_12_win_thread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_new_thread_Click(object sender, EventArgs e)
        {
            ThreadStart d = new ThreadStart(this.Call);
            Thread th = new Thread(d);
            th.IsBackground = true;
            th.Start();//Create a New Thread
            /*
            Thread th2 = new Thread(this.Call1);
            th.IsBackground = true;
            th2.Start();

            Thread th3 = new Thread(() =>
              {
                  MessageBox.Show("New Task 3 using Lambda update1");
              });
            th.IsBackground = true;
            th3.Start();
            */
            MessageBox.Show("Main Thread Task");

            th.Join();

            MessageBox.Show("Main Thread Task 2");

        }
        public void Call()
        {
            MessageBox.Show("New Thread Task Started");
            Thread.Sleep(10000);
            MessageBox.Show("New Thread Task Completed");
        }
        public void Call1()
        {
            MessageBox.Show("New Thread Task2");
        }

    }
}
