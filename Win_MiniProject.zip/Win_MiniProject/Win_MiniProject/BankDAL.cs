﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;




namespace Win_MiniProject
{
    class BankDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(Customer c)
        {
            SqlCommand com_cus_insert = new SqlCommand("add_customer", con);
            com_cus_insert.Parameters.AddWithValue("@name", c.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@email", c.CustomerEmail);
            com_cus_insert.Parameters.AddWithValue("@mobileno", c.CustomerMobile);
            com_cus_insert.Parameters.AddWithValue("@gender", c.CustomerGender);
            com_cus_insert.Parameters.AddWithValue("@password", c.CustomerPassword);
            com_cus_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_cus_insert.Parameters.Add(retdata);

            con.Open();
            com_cus_insert.ExecuteNonQuery();

            int ID = Convert.ToInt32(retdata.Value);

            con.Close();
            return ID;


        }

        public int addAccount(Account a)
        {
            SqlCommand com_ac_ins = new SqlCommand("add_account", con);
            com_ac_ins.Parameters.AddWithValue("@cid", a.CustomerID);
            com_ac_ins.Parameters.AddWithValue("@balance", a.AccountBalance);
            com_ac_ins.Parameters.AddWithValue("@actype", a.AccountType);
            com_ac_ins.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_ac_ins.Parameters.Add(retdata);

            con.Open();
            com_ac_ins.ExecuteNonQuery();

            int ID = Convert.ToInt32(retdata.Value);

            con.Close();
            return ID;




        }


        public List<Account> showAccounts(int cid)
        {
            SqlCommand com_ac_show = new SqlCommand("show_account", con);
            com_ac_show.Parameters.AddWithValue("@cid", cid);
            com_ac_show.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ac_show.ExecuteReader();

            List<Account> culist = new List<Account>();
            while (dr.Read())
            {
                Account ac = new Account();
                ac.AccountID = dr.GetInt32(0);
                ac.CustomerID = dr.GetInt32(1);
                ac.AccountBalance = dr.GetInt32(2);
                ac.AccountType = dr.GetString(3);
                ac.AccountOpeningDate = dr.GetDateTime(4);

                culist.Add(ac);
            }
            con.Close();
            return culist;
        }



        public int addTransaction(Transaction t)
        {
            SqlCommand com_ts_insert = new SqlCommand("add_transaction", con);
            com_ts_insert.Parameters.AddWithValue("@aid", t.AccountID);
            com_ts_insert.Parameters.AddWithValue("@amt", t.Amount);
            com_ts_insert.Parameters.AddWithValue("@transtype", t.Transtype);
            com_ts_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_ts_insert.Parameters.Add(retdata);

            con.Open();
            com_ts_insert.ExecuteNonQuery();

            int ID = Convert.ToInt32(retdata.Value);

            con.Close();
            return ID;


        }


        public List<Transaction> showTransactions(int aid)
        {
            SqlCommand com_ac_show = new SqlCommand("show_transactions", con);
            com_ac_show.Parameters.AddWithValue("@aid", aid);
            com_ac_show.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ac_show.ExecuteReader();

            List<Transaction> tslist = new List<Transaction>();
            while (dr.Read())
            {
                Transaction ts = new Transaction();
                ts.TransactionID = dr.GetInt32(0);
                ts.AccountID = dr.GetInt32(1);
                ts.Amount = dr.GetInt32(2);
                ts.Transtype = dr.GetString(3);
                ts.TransDate = dr.GetDateTime(4);
                tslist.Add(ts);
            }
            con.Close();
            return tslist;
        }
        public bool LoginCustomer(int ID, string Password)
        {

            SqlCommand com_login = new SqlCommand("customer_login", con);
            com_login.Parameters.AddWithValue("@id", ID);
            com_login.Parameters.AddWithValue("@password", Password);
            com_login.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(retdata);
            con.Open();
            com_login.ExecuteNonQuery();
            int count = Convert.ToInt32(retdata.Value);
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
            public List<int> showOnlyAccounts(int cid)
        {
            SqlCommand com_ac_show = new SqlCommand("show_account", con);
            com_ac_show.Parameters.AddWithValue("@cid", cid);
            com_ac_show.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ac_show.ExecuteReader();

            List<int> culist = new List<int>();
            while (dr.Read())
            {

                culist.Add(dr.GetInt32(0));
            }
            con.Close();
            return culist;
        }

        public int AccountBalance(int id)
        {
            SqlCommand com_ac_bal = new SqlCommand("accountbalance", con);
            com_ac_bal.Parameters.AddWithValue("@id", id);
            com_ac_bal.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_ac_bal.Parameters.Add(retdata);
            con.Open();
            com_ac_bal.ExecuteNonQuery();
            int dr = Convert.ToInt32(retdata.Value);

            con.Close();
            return dr;
        
        }




    }
}