create database PathFrontDB

use PathFrontDB

create table tb1_Customers
(
CustomerID int,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerDOB datetime
)

sp_help tb1_Customers

select *from tb1_Customers


insert tb1_Customers values(1001,'john','Chennai','05-04-1997')
insert tb1_Customers values(1002,'ram','Guntur','10-10-1996')
insert tb1_Customers values(1003,'sandeep','Hyderabad','05-05-1997')
insert tb1_Customers values(1004,'Naidu','Tenali','05-05-1995')
insert tb1_Customers values(1005,'Krishna','Bangalore','10-11-1997')

insert tb1_Customers(CustomerID,CustomerName) values(1007,'ABC')

select *from tb1_Customers
select Customerid,Customername from tb1_Customers

select * from tb1_Customers where CustomerCity='Chennai'
update tb1_Customers set CustomerCity= 'Singapur',CustomerName='Raj' where CustomerID=1004

delete tb1_Customers where CustomerID=1005

truncate table tb1_customers

alter table tb1_customers add customerEmail varchar(100)

select * from tb1_Customers
alter table tb1_customers drop column customerEmail

alter table tb1_customers alter column customername varchar(200)

select * from tb1_Customers where CustomerCity in ('Chennai','Bangalore'); 
insert tb1_Customers(CustomerID,CustomerName,CustomerCity) values(1007,'ABC',Null)


select*from tb1_Customers where CustomerCity is null

select *from tb1_Customers order by CustomerDOB asc

select top 1*from tb1_Customers where CustomerDOB is not null
order by CustomerDOB asc


select top 1*from tb1_employee order by employeesalary desc

select len('Hello')

select SUBSTRING('hello',1,4)

select LOWER('HELLO')


select UPPER('hello')

select LEFT('hello',2)

select RIGHT('hello',2)

select ISNUMERIC('12a')

select CEILING(25.01)

select FLOOR(25.99)

select round(253.2595,1)

select ISNULL(tb1_Customers,0)

select * from tb1_Customers order by LEN(tb1_Customers) asc


create table tbl_Employees
(
EmployeeID int,
EmployeeName varchar(100),
EmployeeCity varchar(100),
EmployeeSalary int
)
 
insert tbl_Employees values(1,'Ram','Guntur',10000)
insert tbl_Employees values(2,'Sandeep','Hyderabad',20000)
insert tbl_Employees values(3,'Naidu','Bnagalore',30000)
insert tbl_Employees values(4,'Praveen','Vizag',40000)
insert tbl_Employees values(5,'Sai','Vijayawada',50000)

select sum(EmployeeSalary) from tbl_Employees

select MAX(EmployeeSalary) from tbl_Employees

select MIN(EmployeeSalary) from tbl_Employees

select avg(EmployeeSalary) from tbl_Employees

select count(*) from tbl_Employees

select GETDATE()

select * from tb1_Customers

select customerid,customername,datediff(yy,customerdob,getdate())as 'age',DATENAME(dw,CustomerDOB) as 'day',DATEPART(dw,CustomerDOB) as 'number'
from tb1_Customers

select dateadd(mm,10,customerdob) from tb1_Customers

select CONVERT(varchar(10),employeesalary) from tbl_Employees

select cast(employeesalary as decimal(12,2)) from tbl_Employees

select employeecity,count(*) from tbl_Employees group by EmployeeCity

select employeecity, avg(employeesalary) from tbl_Employees group by EmployeeCity

select employeecity,MAX(employeesalary) from tbl_Employees group by EmployeeCity

select employeecity,count(*) from tbl_Employees where employeesalary>10000 group by employeecity

select employeecity,count(*) from tbl_Employees group by EmployeeCity having count(*)>=1



