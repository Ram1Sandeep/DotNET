create database miniproject

use miniproject 

create table tbl_students
(
StudentID int identity(100,1) primary key,
StudentName varchar(100) not null,
StudentEmailID varchar(100) not null,
StudentPassword varchar(100) not null,
StudentImage varchar(100) not null
)

select * from tbl_students

create table tbl_books
(
BookID int identity(1000,1) primary key,
BookName varchar(100) not null,
AuthorName varchar(100) not null,
BookImage varchar(100) not null,
)

select * from tbl_books

create table tbl_issuebooks
(
IssueID int identity(1,1) primary key,
BookID int not null foreign key references tbl_books(BookID),
StudentID int not null foreign key references tbl_students(StudentID),
IssueStatus varchar(100) not null,
IssueDate DateTime not null
)
select * from tbl_issuebooks


create proc proc_AddStudents(@Sname varchar(100),@Semailid varchar(100),@Spassword varchar(100),@Simage varchar(100))
as
insert tbl_students values(@Sname,@Semailid,@Spassword,@Simage)
return @@identity 

create proc proc_AddBooks(@Bname varchar(100),@Bauthorname varchar(100),@Bbookimage varchar(100))
as
insert tbl_books values(@Bname,@Bauthorname,@Bbookimage)
return @@identity

create proc proc_AddIssueBooks(@Ibookid int,@Istudentid int,@Iissuestatus varchar(100))
as
insert tbl_issuebooks values(@Ibookid,@Istudentid,@Iissuestatus,GETDATE())
return @@identity





