﻿namespace day_9_win_ado
{
    partial class frm_Find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_employeedoj = new System.Windows.Forms.TextBox();
            this.lbl_employeedoj = new System.Windows.Forms.Label();
            this.txt_employeeid = new System.Windows.Forms.TextBox();
            this.lbl_employeeid = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.txt_employeecity = new System.Windows.Forms.TextBox();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_employeedoj
            // 
            this.txt_employeedoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeedoj.Location = new System.Drawing.Point(289, 259);
            this.txt_employeedoj.Name = "txt_employeedoj";
            this.txt_employeedoj.Size = new System.Drawing.Size(149, 26);
            this.txt_employeedoj.TabIndex = 35;
            this.txt_employeedoj.TextChanged += new System.EventHandler(this.txt_employeedoj_TextChanged);
            // 
            // lbl_employeedoj
            // 
            this.lbl_employeedoj.AutoSize = true;
            this.lbl_employeedoj.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeedoj.Location = new System.Drawing.Point(72, 261);
            this.lbl_employeedoj.Name = "lbl_employeedoj";
            this.lbl_employeedoj.Size = new System.Drawing.Size(133, 22);
            this.lbl_employeedoj.TabIndex = 34;
            this.lbl_employeedoj.Text = "Employee DOJ:";
            this.lbl_employeedoj.Click += new System.EventHandler(this.lbl_employeedoj_Click);
            // 
            // txt_employeeid
            // 
            this.txt_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeeid.Location = new System.Drawing.Point(289, 53);
            this.txt_employeeid.Name = "txt_employeeid";
            this.txt_employeeid.Size = new System.Drawing.Size(149, 26);
            this.txt_employeeid.TabIndex = 33;
            this.txt_employeeid.TextChanged += new System.EventHandler(this.txt_employeeid_TextChanged);
            // 
            // lbl_employeeid
            // 
            this.lbl_employeeid.AutoSize = true;
            this.lbl_employeeid.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeeid.Location = new System.Drawing.Point(72, 53);
            this.lbl_employeeid.Name = "lbl_employeeid";
            this.lbl_employeeid.Size = new System.Drawing.Size(117, 22);
            this.lbl_employeeid.TabIndex = 32;
            this.lbl_employeeid.Text = "Employee ID:";
            this.lbl_employeeid.Click += new System.EventHandler(this.lbl_employeeid_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(532, 171);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(87, 31);
            this.btn_delete.TabIndex = 31;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(532, 108);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(87, 33);
            this.btn_update.TabIndex = 30;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(532, 53);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(87, 26);
            this.btn_find.TabIndex = 29;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(289, 203);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(149, 26);
            this.txt_employeepassword.TabIndex = 28;
            this.txt_employeepassword.TextChanged += new System.EventHandler(this.txt_employeepassword_TextChanged);
            // 
            // txt_employeecity
            // 
            this.txt_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeecity.Location = new System.Drawing.Point(289, 159);
            this.txt_employeecity.Name = "txt_employeecity";
            this.txt_employeecity.Size = new System.Drawing.Size(149, 26);
            this.txt_employeecity.TabIndex = 27;
            this.txt_employeecity.TextChanged += new System.EventHandler(this.txt_employeecity_TextChanged);
            // 
            // txt_employeename
            // 
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(289, 104);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(149, 26);
            this.txt_employeename.TabIndex = 26;
            this.txt_employeename.TextChanged += new System.EventHandler(this.txt_employeename_TextChanged);
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeepassword.Location = new System.Drawing.Point(72, 207);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(178, 22);
            this.lbl_employeepassword.TabIndex = 25;
            this.lbl_employeepassword.Text = "Employee Password:";
            this.lbl_employeepassword.Click += new System.EventHandler(this.lbl_employeepassword_Click);
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(72, 163);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(131, 22);
            this.lbl_employeecity.TabIndex = 24;
            this.lbl_employeecity.Text = "Employee City:";
            this.lbl_employeecity.Click += new System.EventHandler(this.lbl_employeecity_Click);
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(72, 108);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(147, 22);
            this.lbl_employeename.TabIndex = 23;
            this.lbl_employeename.Text = "Employee Name:";
            this.lbl_employeename.Click += new System.EventHandler(this.lbl_employeename_Click);
            // 
            // frm_Find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 338);
            this.Controls.Add(this.txt_employeedoj);
            this.Controls.Add(this.lbl_employeedoj);
            this.Controls.Add(this.txt_employeeid);
            this.Controls.Add(this.lbl_employeeid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeecity);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "frm_Find";
            this.Text = "frm_Find";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_employeedoj;
        private System.Windows.Forms.Label lbl_employeedoj;
        private System.Windows.Forms.TextBox txt_employeeid;
        private System.Windows.Forms.Label lbl_employeeid;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.TextBox txt_employeecity;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeename;
    }
}