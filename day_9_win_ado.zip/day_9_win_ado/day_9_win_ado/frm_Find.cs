﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win_ado
{
    public partial class frm_Find : Form
    {
        public frm_Find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text==string.Empty)
            {
                MessageBox.Show("Enter Correct ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                Employee emp = dal.Find(id);
                if(emp!=null)
                {
                    txt_employeename.Text = emp.EmployeeName;
                    txt_employeepassword.Text = emp.EmployeePassword;
                    txt_employeecity.Text = emp.EmployeeCity;
                    txt_employeedoj.Text = emp.EmployeeDOJ.ToString();

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
             
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_employeecity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_employeepassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                string city = txt_employeecity.Text;
                string password = txt_employeepassword.Text;

                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Update(ID, city, password);
                if(status)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }


        }

        private void btn_delete_Click(object sender, EventArgs e)
        {

            if (txt_employeeid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_employeeid.Text);
                EmployeeDAL dal = new EmployeeDAL();
                bool status = dal.Delete(ID);
                if(status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }

            }

        }

        private void lbl_employeedoj_Click(object sender, EventArgs e)
        {

        }

        private void txt_employeeid_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_employeeid_Click(object sender, EventArgs e)
        {

        }

        private void txt_employeedoj_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_employeepassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_employeecity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_employeename_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_employeepassword_Click(object sender, EventArgs e)
        {

        }

        private void lbl_employeecity_Click(object sender, EventArgs e)
        {

        }

        private void lbl_employeename_Click(object sender, EventArgs e)
        {

        }
    }
}
