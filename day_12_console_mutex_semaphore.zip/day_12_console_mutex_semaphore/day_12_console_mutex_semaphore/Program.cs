﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace day_12_console_mutex_semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            //Mutex m = new Mutex(false,"ABC",out status);
            //m.ReleaseMutex();
            //Console.WriteLine(status);

            Semaphore sm = new Semaphore(3, 3);

            Task t1 = Task.Run(() =>
            {
                // m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 1 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 1 Completed");
                sm.Release();
                //m.ReleaseMutex();
            });
            Task t2 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 2 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 2 Completed");
                sm.Release();
               // m.ReleaseMutex();
            });
            Task t3 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task 3 Started");
                Thread.Sleep(10000);
                Console.WriteLine("Task 3 Completed");
                sm.Release();
                // m.ReleaseMutex();
            });

            Console.ReadLine();
        }
    }
}
