﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc_model.Models;

namespace mvc_model.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddStudent()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddStudent(StudentModel model,HttpPostedFileBase imgfile)
        {
            if(ModelState.IsValid)
            {
                model.StudentImageAddress = "/Images/" + Guid.NewGuid() + ".jpg";
                imgfile.SaveAs(Server.MapPath(model.StudentImageAddress));
                StudentsDAL dal = new StudentsDAL();
                int id = dal.AddStudent(model);
                ViewBag.msg = "Student ID :" + id;
            }
            return View();

        }

        public ActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Search(string key)
        {
            StudentsDAL dal = new StudentsDAL();
            List<StudentModel> list = dal.SearchStudent(key);
            return View(list); // Passing Model to view
        }
        public ActionResult Delete(int id)
        {
            StudentsDAL dal = new StudentsDAL();
            dal.Delete(id);
            return View();
        }
        public ActionResult Details(int id)
        {
            StudentsDAL dal = new StudentsDAL();
            StudentModel model = dal.Find(id);
            return View(model);
        }
        public ActionResult Edit(int id)
        {
            StudentsDAL dal = new StudentsDAL();
            StudentModel model = dal.Find(id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(StudentModel model)
        {
            StudentsDAL dal = new StudentsDAL();
            dal.update(model.StudentID, model.StudentPassword, model.StudentMobileNo);
            return View("StudentUpdatedView");
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            StudentsDAL dal = new StudentsDAL();
            bool status = dal.login(model.LoginID, model.Password);
            if(status==true)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid User ID or Password";
                return View();
            }
        }
        

    }
}