﻿namespace day_9_win3_dal
{
    partial class Show_Students
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_students = new System.Windows.Forms.DataGridView();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.lbl_studentcity = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_students)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_students
            // 
            this.dg_students.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_students.Location = new System.Drawing.Point(110, 189);
            this.dg_students.Name = "dg_students";
            this.dg_students.Size = new System.Drawing.Size(525, 150);
            this.dg_students.TabIndex = 20;
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(504, 130);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(131, 26);
            this.btn_search.TabIndex = 19;
            this.btn_search.Text = "Search(All)";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(504, 53);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(131, 26);
            this.btn_find.TabIndex = 18;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(293, 130);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(130, 26);
            this.txt_search.TabIndex = 17;
            // 
            // txt_city
            // 
            this.txt_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_city.Location = new System.Drawing.Point(293, 53);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(130, 26);
            this.txt_city.TabIndex = 16;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(106, 130);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(70, 21);
            this.lbl_search.TabIndex = 15;
            this.lbl_search.Text = "Search :";
            // 
            // lbl_studentcity
            // 
            this.lbl_studentcity.AutoSize = true;
            this.lbl_studentcity.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_studentcity.Location = new System.Drawing.Point(106, 58);
            this.lbl_studentcity.Name = "lbl_studentcity";
            this.lbl_studentcity.Size = new System.Drawing.Size(158, 21);
            this.lbl_studentcity.TabIndex = 14;
            this.lbl_studentcity.Text = "Enter Student City :";
            // 
            // Show_Students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 393);
            this.Controls.Add(this.dg_students);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_studentcity);
            this.Name = "Show_Students";
            this.Text = "Show_Students";
            ((System.ComponentModel.ISupportInitialize)(this.dg_students)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_students;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Label lbl_studentcity;
    }
}