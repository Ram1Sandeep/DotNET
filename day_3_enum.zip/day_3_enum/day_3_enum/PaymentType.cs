﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using day_3_enum_var_dynamic_using;

namespace day_3_enum_var_dynamic_using
{
    enum PaymentType
    {
        COD, Cash=3, Card, NetBanking

    }
}
