﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace day_4_collections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList List = new ArrayList();
            List.Add(1000);
            List.Add(2000);
            List.Add(3000);
            int a = 4000;
            List.Add(a);
            List.Add("ABC");

            int a1 = Convert.ToInt32(List[0]);
            string s1 = List[4].ToString();

            Console.WriteLine(a1);
            Console.WriteLine(s1);

            //foreach(int m in List)
            //{
             //   Console.WriteLine(m);
            //}

            Console.WriteLine(List.Count);
            List.Remove(1000);
            List.Remove(0);
            Console.ReadLine();
        }
    }
}
