﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_9_win3_dal
{
    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string StudentCity { get; set;}
        public string StudentAddress { get; set; }
        public string StudentEmailID { get; set; }

        public string StudentPassword { get; set; }
       
    }
}
