﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win3_dal
{
    public partial class Show_Students : Form
    {
        public Show_Students()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            StudentDAL dal = new StudentDAL();
            string city = txt_city.Text;
            List<Student> list = dal.ShowStudent(city);
            dg_students.DataSource = list;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            StudentDAL dal = new StudentDAL();
            string Key = txt_search.Text;
            List<Student> list = dal.SearchStudent(Key);
            dg_students.DataSource = list;
        }
    }
}
