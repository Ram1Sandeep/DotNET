﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class MyAccount : Form
    {
        public MyAccount()
        {
            InitializeComponent();
        }

        private void btn_showaccounts_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter CustomerID");
            }
            else
            {
                txt_customerid.Text = Test.cid.ToString();
                // txt_customerid.
                txt_customerid.Enabled = false;
                BankDAL dal = new BankDAL();
                List<Account> list= dal.showAccounts(Convert.ToInt32(txt_customerid.Text));
                
                dgv_showaccounts.DataSource = list;
            }
        }

        private void MyAccount_Load(object sender, EventArgs e)
        {
            txt_customerid.Text = Test.cid.ToString();
            txt_customerid.Enabled = false;
        }
    }
}
