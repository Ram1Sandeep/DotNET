﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace day_11_console_linq_XML
{
    class Program
    {
        static void Main(string[] args)
        {
            XElement orders = new XElement("Orders",
                new XElement("Order", new XElement("OrderID", "1001"),
                                     new XElement("CustomerName", "Raj"),
                                     new XElement("OrderAmt", "2000")),
                new XElement("Order", new XElement("OrderID", "1002"),
                                     new XElement("CustomerName", "Krishna"),
                                     new XElement("OrderAmt", "3000"))
                );

            orders.Save(@"C:\Xml/orders.xml");
            Console.WriteLine("Xml File Created");


            /*
            string url = @"D:\dotnet\day_11_console_linq_XML\day_11_console_linq_XML\Customer.xml";

            XDocument doc = XDocument.Load(url);

            var data = from a in doc.Descendants("Customer")
                       select new
                       {
                           CID = a.Element("CustomerID").Value,
                           CName = a.Element("CustomerName").Value,
                           CCity = a.Element("CustomerCity").Value

                       };
            foreach(var d in data)
            {
                Console.WriteLine(d.CID + " " + d.CName + " " + d.CCity);
            }
            */
            Console.ReadLine();
            

        }
    }
}
