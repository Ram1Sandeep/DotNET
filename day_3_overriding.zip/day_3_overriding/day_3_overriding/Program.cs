﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_3_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter EmployeeID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary:");
            int salary = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter type of Employee:");
            string type = Console.ReadLine();


            Employee obj = null;
            
            if (type=="Employee")
            {
                obj = new Employee(id, name, salary);
            }
            else if(type=="Contract")
            {
                obj = new Employee_Contract(id, name, salary);
            }
            else if(type=="Trainee")
            {
                obj = new Employee_Trainee(id, name, salary);
            }
            
            if (obj != null)
            {

                string Work = obj.GetWork();
                Console.WriteLine(Work);

                Console.WriteLine("Enter Days:");
                int Days = Convert.ToInt32(Console.ReadLine());
                int currentmonthsalary = obj.GetSalary(Days);
                Console.WriteLine("Salary:" + currentmonthsalary);
            }
            Console.ReadLine();
        }
    }
}
