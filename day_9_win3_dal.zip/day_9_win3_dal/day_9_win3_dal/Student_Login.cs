﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win3_dal
{
    public partial class Student_Login : Form
    {
        public Student_Login()
        {
            InitializeComponent();
        }

        private void btn_login_sql_injecton_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string password = txt_password.Text;

            StudentDAL dal = new StudentDAL();
            bool status = dal.LoginSqlInjection(id, password);
            if (status)
            {
                MessageBox.Show("Valid User");
            }
            else
            {
                MessageBox.Show("Invalid User");
            }

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(txt_loginid.Text);
            string password = txt_password.Text;
            try
            {
                StudentDAL dal = new StudentDAL();
                bool status = dal.Login(ID, password);
                if (status)
                {
                    MessageBox.Show("Valid User");
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
            catch (System.Data.SqlClient.SqlException exp)
            {
                MessageBox.Show("SQL Error");
            }
            catch (Exception exp)
            {
                MessageBox.Show("Try Again");
            }
            finally
            {
                MessageBox.Show("Finally Block");
            }
        }
    }
}
