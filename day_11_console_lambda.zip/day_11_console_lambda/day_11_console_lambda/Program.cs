﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_11_console_lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "Bangalore", CustomerName = "Ram" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 26, CustomerCity = "Guntur", CustomerName = "Sai" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 27, CustomerCity = "Guntur", CustomerName = "Praveen" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 28, CustomerCity = "Guntur", CustomerName = "Kiran" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 29, CustomerCity = "Vijayawada", CustomerName = "Mani" });

            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "Oneplus 5", ItemPrice = 30000 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 1, ItemName = "Oneplus 5T", ItemPrice = 33000 });

            ordlist.Add(new Order { OrderID = 1003, CustomerID = 2, ItemName = "Oneplus 6", ItemPrice = 35000 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 3, ItemName = "Oneplus 6T", ItemPrice = 33000 });


        
            var data = custlist.Where((c)=>c.CustomerCity=="Guntur");
            foreach(var a in data)
            {
                Console.WriteLine(a.CustomerID + " " + a.CustomerName);

            }

            var count = custlist.Count  ((c) => c.CustomerCity == "Guntur");
            Console.WriteLine(count);

            var obj = custlist.FirstOrDefault((c) => c.CustomerID ==1);
            if(obj!=null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName);

            }
            else
            {
                Console.WriteLine("Not Found");
            }

            var status = custlist.Exists((c) => c.CustomerID == 1);
            Console.WriteLine(status);

            var dataprojection=custlist.Where((c) => c.CustomerCity == "Guntur").
            Select((s) => new { CID = s.CustomerID, CName = s.CustomerName });

            foreach(var d in dataprojection)
            {
                Console.WriteLine(d.CID + " " + d.CName);
            }

            var dataorderby =
                custlist.Where((c) => c.CustomerAge > 20).OrderBy((o) => o.CustomerName).ThenByDescending((o1) => o1.CustomerCity);

            foreach(var d in dataorderby)
            {
                Console.WriteLine(d.CustomerID + " " + d.CustomerName + " " + d.CustomerCity);
            }

            var groupdata=custlist.GroupBy((g)=>g.CustomerCity).
                Select((s) => new {
                City = s.Key,
                Count = s.Count(),
                Avg = s.Average((a) => a.CustomerAge)});

            foreach(var a in groupdata)
            {
                Console.WriteLine(a.City + " " + a.Count + " " + a.Avg);
            }

            var joindata = custlist.Join(ordlist,
                (c) => c.CustomerID,
                (o) => o.CustomerID,
                (c, o) => new
                {
                    CID = c.CustomerID,
                    CName = c.CustomerName,
                    OID = o.OrderID,
                    IName = o.ItemName,
                    IPrice = o.ItemPrice
                });

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.IName + " " + j.IPrice);
            }


            Console.ReadLine();

        }
    }
}
