﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace MVC_DAL_Assignment.Models
{
    public class EmployeesDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddEmployee(EmployeeModel model)
        {
            try
            {
                SqlCommand com_add = new SqlCommand("proc_addemployee", con);
                com_add.Parameters.AddWithValue("@name", model.EmployeeName);
                com_add.Parameters.AddWithValue("@city", model.EmployeeCity);
                com_add.Parameters.AddWithValue("@email", model.EmployeeEmailID);
                com_add.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_add.Parameters.Add(retdata);
                con.Open();
                com_add.ExecuteNonQuery();

                int ID = Convert.ToInt32(retdata.Value);

                con.Close();
                return ID;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public EmployeeModel Find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findemployee", con);
                com_find.Parameters.AddWithValue("@id", id);
                com_find.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader rd = com_find.ExecuteReader();
                EmployeeModel m = new EmployeeModel();

                if (rd.Read())
                {
                    m.EmployeeID = rd.GetInt32(0);
                    m.EmployeeName = rd.GetString(1);
                    m.EmployeeCity = rd.GetString(2);
                    m.EmployeeEmailID = rd.GetString(3);

                }
                con.Close();
                if (rd != null)
                {
                    return m;
                }
                else
                {
                    return null;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<EmployeeModel> SearchEmployee(string key)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findemployee", con);
                com_find.Parameters.AddWithValue("@id", key);
                com_find.CommandType = CommandType.StoredProcedure;
                List<EmployeeModel> list = new List<EmployeeModel>();
                con.Open();
                SqlDataReader rd = com_find.ExecuteReader();

                while (rd.Read())
                {
                    EmployeeModel m = new EmployeeModel();
                    m.EmployeeID = rd.GetInt32(0);
                    m.EmployeeName = rd.GetString(1);
                    m.EmployeeCity = rd.GetString(2);
                    m.EmployeeEmailID = rd.GetString(3);                   
                    list.Add(m);

                }
                con.Close();
                if (rd != null)
                {
                    return list;
                }
                else
                {
                    return null;
                }


            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool Delete(int id)
        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deleteemployee", con);
                com_delete.Parameters.AddWithValue("@id", id);
                com_delete.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_delete.Parameters.Add(retdata);
                com_delete.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool update(int id, string name, string city)
        {
            try
            {
                SqlCommand com_update = new SqlCommand("proc_updateemployee", con);
                com_update.Parameters.AddWithValue("@id", id);
                com_update.Parameters.AddWithValue("@name", name);
                com_update.Parameters.AddWithValue("@city", city);
                com_update.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_update.Parameters.Add(retdata);
                com_update.ExecuteNonQuery();
                int count = Convert.ToInt32(retdata.Value);
                con.Close();
                if (count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }




    }
}