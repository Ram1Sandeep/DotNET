﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    class Manager
    {
        public void GetEmployee(IManagerEmp e)
        {
            int ID = e.GetEmployeeID();
            Console.WriteLine("Employee ID" + ID);
            int exp = e.GetEmployeeExp();
            Console.WriteLine("Employee Exp" + exp);
            string project = e.GetEmployeeProjectDetails();
            Console.WriteLine("Employee Project Details" + project);

        }
    }
}
