﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_callbyvalue_callbyref
{
    class Program
    {
        static void Main(string[] args)
        {
            ABC obj1 = new ABC();
            obj1.Call();
            obj1.GetData();
            int[] marks = new int[3];
            marks[0] = 10;
            marks[1] = 20;
            marks[2] = 30;

            Test obj = new Test();
            obj.CallArray(10,40,66,99);

            int orderamt = obj.GetOrderValue(itemqty:2,itemprice:2000);
            Console.WriteLine(orderamt);

            int a = 100;
            obj.call(ref a);
            Console.WriteLine(a);
            Console.ReadLine();

        }
    }
}
