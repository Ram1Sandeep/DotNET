﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_MiniProject
{
    class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }

        public string CustomerEmail { get; set; }

        public string CustomerMobile { get; set; }

        public string CustomerGender { get; set; }

        public string CustomerPassword { get; set; }
    }
}
