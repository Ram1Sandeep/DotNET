﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_3_Assignment_Order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemQty;
        private int ItemPrice;

        public Order(int OrderID,string CustomerName,int ItemQty,int ItemPrice)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;

        }
        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemQty
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public virtual int GetOrderValue()
        {
            return this.ItemQty * this.PItemPrice;
        }
    }
    
}
