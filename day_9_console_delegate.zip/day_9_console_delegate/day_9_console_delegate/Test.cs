﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_9_console_delegate
{
    class Test
    {
        public delegate void del(string str);

        public void call1(string str)
        {
            Console.WriteLine("Call1:" + str);
        }
        public void call2(string str)
        {
            Console.WriteLine("Call2:" + str);
        }
    }
}
