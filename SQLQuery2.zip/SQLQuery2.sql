declare @count int=0;
set @count=100;
select @count;
if(@count>0)
begin

--insert

end
else
begin

--update

end 
select @count


declare @count int=0;
while (@count<10)
begin
select @count;
set @count=@count+1;
end

alter proc sp_employees
as
select * from tbl_Employees order by EmployeeSalary desc

exec sp_employees

create proc sp_employees_city(@city varchar(100))
as
select * from tbl_Employees where EmployeeCity=@city

exec sp_employees_city 'guntur'

select * from tbl_accounts

create  proc sp_add_account(@name varchar(100),@balance int)
as
if(@balance>100)
begin
insert
tbl_accounts values(@name,@balance)

return @@identity
end
else
begin
return 0
end

declare @r  int
exec @r=sp_add_account 'abcd',2000
select @r


create proc sp_account_balance(@accountid int)
as
declare @balance int
select @balance=accountbalance from tbl_accounts where accountid=@accountid;
return @balance

declare @bal int
exec @bal=sp_account_balance 1000
select @bal


select * from tbl_Employees

create proc sp_employeedetails(@id int,@name varchar(100) output, @city varchar(100) output)
as
select @name=employeename,@city=employeecity from tbl_employees where EmployeeID=@id

declare @name varchar(100)
declare @city varchar(100)
exec sp_employeedetails 1, @name output,@city output
select @name,@city


create table tbl_student
(
studentid int ,
studentname varchar(100),
studentcity varchar(100)
)

alter trigger trg_add_student
on tbl_student
for insert 
as
begin
select * from inserted
select 'trigger fired'
end


insert tbl_student values(1,'a','pune')
select * from tbl_student




create table stock
(
itemid int primary key,
itemqty  int 
)
insert stock values(2,100)
select * from stock


create table orders 
(
orderid int primary key,
itemid int not null foreign key references stock(itemid)
itemqty int not null,
itemprice int check(itemprice>0)
)


insert orders values(1,2,30,300)
select * from orders

create  trigger trg_update_stock
on orders
for insert 
as
begin
declare @itemid int
declare @itemqty int
select @itemid=itemid,@itemqty=itemqty from inserted
update stock set itemqty=itemqty-@itemqty where itemid=@itemid
end


select * from tbl_Employees

alter view v_employees_BGL
with encryption, schemabinding
as
select employeeid,EmployeeName,EmployeeSalary,EmployeeCity from dbo.tbl_Employees where EmployeeCity='guntur'
with check option

drop table tbl_Employees
sp_helptext v_employees_bgl

select * from v_employees_BGL where employeesalary>50000
insert v_employees_BGL values(1005,'abc','guntur',20000)
insert v_employees_BGL values(1006,'abc','guntur',20000)


create table t1
(
code int,
name varchar(100)
)
create table t2
(
code int,
city varchar(100)
)
insert t1 values(1,'a');
insert t2 values(1,'bgl');
select * from t1
select * from t2

create view v_data
as
select t1.code,t1.name,t2.city from t1 join t2 on t1.code=t2.code

select * from v_data
insert v_data values(2,'abc','pune')

create trigger trg_view 
on v_data
instead of insert
as
begin
declare @code int
declare @name varchar(100)
declare @city varchar(100)
select @code=code,@name=name,@city=city from inserted
insert t1 values(@code,@name)
insert t2 values(@code,@city)
end


create table tbl_employeeinfo
(
employeeid int identity(1,1),
employeename varchar(100),
employeecity varchar(100)
)


declare @c int=0;
while (@c<50000)
begin
insert tbl_employeeinfo values('abcd','hyd')
set @c=@c+1;
end

select * from tbl_employeeinfo where employeeid=49999

create clustered index idx
on tbl_employeeinfo(employeeid)


select * from tbl_employees

begin tran tr1

insert tbl_Employees values(1011,'abc','bgl',200000)

select * from  tbl_employees

rollback tran

commit tran 





