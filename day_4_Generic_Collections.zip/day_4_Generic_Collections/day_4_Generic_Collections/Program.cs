﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_Generic_Collections
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1, "PathFront");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter Your Operation: 1.Add, 2.Find, 3.Remove, 4.Show, 5.Exit, 6.Leave");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        Console.WriteLine("Enter Student Name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter Student City:");
                        string city = Console.ReadLine();
                        Student s = new Student(name, city);
                        c.AddStudent(s);
                        Console.WriteLine("Student Added:" + s.PStudentID);
                        break;
                    case 2:
                        Console.WriteLine("Enter StudentID:");
                        int ID = Convert.ToInt32(Console.ReadLine());
                        Student obj = c.Find(ID);
                        if (obj!=null)
                        {
                            Console.WriteLine(obj.PStudentID + " " + obj.PStudentName);

                        }
                        else
                        {
                            Console.WriteLine("Student not Found");

                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter Student ID");
                        int SID = Convert.ToInt32(Console.ReadLine());
                        bool status = c.Remove(SID);
                        if(status)
                        {
                            Console.WriteLine("Student Removed");
                        }
                        else
                        {
                            Console.WriteLine("Student Not Found");

                        }
                        break;
                    case 4:
                        c.ShowAll();
                        break;
                    case 5:
                        flag = true;
                        break;
                    case 6:
                        Console.WriteLine("Enter Student ID:");
                        int StudentID = Convert.ToInt32(Console.ReadLine());
                        Student Sobj = c.Find(StudentID);
                        Console.WriteLine("Enter Reason:");
                        string Reason = Console.ReadLine();
                        Sobj.TakeLeave(Reason);
                        break;

                }
            }
        }
    }
}
