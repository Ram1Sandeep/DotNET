﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win_ado
{
    public partial class frm_Show_Employees : Form
    {
        public frm_Show_Employees()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string city = txt_city.Text;
            List<Employee> list = dal.ShowEmployee(city);
            dg_employees.DataSource = list;

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            string Key = txt_search.Text;
            List<Employee> list = dal.SearchEmployee(Key);
            dg_employees.DataSource = list;
        }

        private void lbl_search_Click(object sender, EventArgs e)
        {

        }

        private void txt_city_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_employeecity_Click(object sender, EventArgs e)
        {

        }

        private void dg_employees_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
