﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_practice3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter orderid");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name");
            string name = Console.ReadLine();
            Console.WriteLine("enter item name");
            string item = Console.ReadLine();
            Console.WriteLine("enter item price");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item quantity");
            int quantity = Convert.ToInt32(Console.ReadLine());


            order obj = new order(id, name, item, price, quantity);

            int a = obj.getorderamount();
            Console.WriteLine(a);

            string b = obj.getdetails();
            Console.WriteLine(b);

            Console.ReadLine();
             

        }
    }
}
