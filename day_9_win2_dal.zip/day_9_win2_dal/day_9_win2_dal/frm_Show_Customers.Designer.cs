﻿namespace day_9_win2_dal
{
    partial class frm_Show_Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_customers = new System.Windows.Forms.DataGridView();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.lbl_search = new System.Windows.Forms.Label();
            this.lbl_customercity = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_customers)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_customers
            // 
            this.dg_customers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_customers.Location = new System.Drawing.Point(48, 160);
            this.dg_customers.Name = "dg_customers";
            this.dg_customers.Size = new System.Drawing.Size(525, 150);
            this.dg_customers.TabIndex = 13;
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(442, 101);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(131, 26);
            this.btn_search.TabIndex = 12;
            this.btn_search.Text = "Search(All)";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(442, 24);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(131, 26);
            this.btn_find.TabIndex = 11;
            this.btn_find.Text = "Find";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(231, 101);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(130, 26);
            this.txt_search.TabIndex = 10;
            // 
            // txt_city
            // 
            this.txt_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_city.Location = new System.Drawing.Point(231, 24);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(130, 26);
            this.txt_city.TabIndex = 9;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(44, 101);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(70, 21);
            this.lbl_search.TabIndex = 8;
            this.lbl_search.Text = "Search :";
            // 
            // lbl_customercity
            // 
            this.lbl_customercity.AutoSize = true;
            this.lbl_customercity.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customercity.Location = new System.Drawing.Point(44, 29);
            this.lbl_customercity.Name = "lbl_customercity";
            this.lbl_customercity.Size = new System.Drawing.Size(172, 21);
            this.lbl_customercity.TabIndex = 7;
            this.lbl_customercity.Text = "Enter Customer City :";
            // 
            // frm_Show_Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 390);
            this.Controls.Add(this.dg_customers);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.lbl_search);
            this.Controls.Add(this.lbl_customercity);
            this.Name = "frm_Show_Customers";
            this.Text = "frm_Show_Customers";
            ((System.ComponentModel.ISupportInitialize)(this.dg_customers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_customers;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Label lbl_customercity;
    }
}