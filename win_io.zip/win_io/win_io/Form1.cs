﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace win_io
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_binary_writer_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test Folder/a.txt", FileMode.OpenOrCreate,FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            int a = 100;
            bw.Write(a);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File Created");

        }

        private void btn_binary_reader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test Folder/a.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int a = br.ReadInt32();
            fs.Close();
            MessageBox.Show(a.ToString());

        }

        private void btn_stream_writer_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test Folder/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            string str = "hello dotnet";
            sw.WriteLine(str);
            sw.Flush();
            fs.Close();
            MessageBox.Show("File Created");


        }

        private void btn_stream_reader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:/Test Folder/b.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show(str);

            

        }
    }
}
