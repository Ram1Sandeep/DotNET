﻿namespace Win_MiniProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.btn_resetnew = new System.Windows.Forms.Button();
            this.btn_newcustomer = new System.Windows.Forms.Button();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.txt_customermobile = new System.Windows.Forms.TextBox();
            this.txt_Customeremail = new System.Windows.Forms.TextBox();
            this.txt_Customername = new System.Windows.Forms.TextBox();
            this.lbl_newpassword = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.lbl_mobile = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_newcustomer = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.tbl_login = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_female.Location = new System.Drawing.Point(606, 260);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(95, 29);
            this.rdb_female.TabIndex = 40;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_male.Location = new System.Drawing.Point(527, 260);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(73, 29);
            this.rdb_male.TabIndex = 39;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "Male";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // btn_resetnew
            // 
            this.btn_resetnew.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resetnew.Location = new System.Drawing.Point(582, 390);
            this.btn_resetnew.Name = "btn_resetnew";
            this.btn_resetnew.Size = new System.Drawing.Size(98, 46);
            this.btn_resetnew.TabIndex = 38;
            this.btn_resetnew.Text = "Reset";
            this.btn_resetnew.UseVisualStyleBackColor = true;
            this.btn_resetnew.Click += new System.EventHandler(this.btn_resetnew_Click);
            // 
            // btn_newcustomer
            // 
            this.btn_newcustomer.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newcustomer.Location = new System.Drawing.Point(390, 390);
            this.btn_newcustomer.Name = "btn_newcustomer";
            this.btn_newcustomer.Size = new System.Drawing.Size(158, 46);
            this.btn_newcustomer.TabIndex = 37;
            this.btn_newcustomer.Text = "New Customer";
            this.btn_newcustomer.UseVisualStyleBackColor = true;
            this.btn_newcustomer.Click += new System.EventHandler(this.btn_newcustomer_Click_1);
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(527, 312);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(131, 30);
            this.txt_customerpassword.TabIndex = 36;
            // 
            // txt_customermobile
            // 
            this.txt_customermobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobile.Location = new System.Drawing.Point(527, 201);
            this.txt_customermobile.Name = "txt_customermobile";
            this.txt_customermobile.Size = new System.Drawing.Size(131, 30);
            this.txt_customermobile.TabIndex = 35;
            // 
            // txt_Customeremail
            // 
            this.txt_Customeremail.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Customeremail.Location = new System.Drawing.Point(527, 153);
            this.txt_Customeremail.Name = "txt_Customeremail";
            this.txt_Customeremail.Size = new System.Drawing.Size(131, 30);
            this.txt_Customeremail.TabIndex = 34;
            // 
            // txt_Customername
            // 
            this.txt_Customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Customername.Location = new System.Drawing.Point(527, 99);
            this.txt_Customername.Name = "txt_Customername";
            this.txt_Customername.Size = new System.Drawing.Size(131, 30);
            this.txt_Customername.TabIndex = 33;
            // 
            // lbl_newpassword
            // 
            this.lbl_newpassword.AutoSize = true;
            this.lbl_newpassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newpassword.Location = new System.Drawing.Point(385, 315);
            this.lbl_newpassword.Name = "lbl_newpassword";
            this.lbl_newpassword.Size = new System.Drawing.Size(89, 22);
            this.lbl_newpassword.TabIndex = 32;
            this.lbl_newpassword.Text = "Password";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(385, 260);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(68, 22);
            this.lbl_gender.TabIndex = 31;
            this.lbl_gender.Text = "Gender";
            // 
            // lbl_mobile
            // 
            this.lbl_mobile.AutoSize = true;
            this.lbl_mobile.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobile.Location = new System.Drawing.Point(385, 206);
            this.lbl_mobile.Name = "lbl_mobile";
            this.lbl_mobile.Size = new System.Drawing.Size(67, 22);
            this.lbl_mobile.TabIndex = 30;
            this.lbl_mobile.Text = "Mobile";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(385, 161);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(54, 22);
            this.lbl_email.TabIndex = 29;
            this.lbl_email.Text = "Email";
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(385, 104);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(58, 22);
            this.lbl_name.TabIndex = 28;
            this.lbl_name.Text = "Name";
            // 
            // lbl_newcustomer
            // 
            this.lbl_newcustomer.AutoSize = true;
            this.lbl_newcustomer.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newcustomer.Location = new System.Drawing.Point(476, 52);
            this.lbl_newcustomer.Name = "lbl_newcustomer";
            this.lbl_newcustomer.Size = new System.Drawing.Size(169, 28);
            this.lbl_newcustomer.TabIndex = 27;
            this.lbl_newcustomer.Text = "New Customer";
            // 
            // btn_reset
            // 
            this.btn_reset.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(187, 237);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(100, 40);
            this.btn_reset.TabIndex = 26;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click_1);
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(28, 237);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(98, 40);
            this.btn_login.TabIndex = 25;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // txt_password
            // 
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(142, 153);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(145, 30);
            this.txt_password.TabIndex = 24;
            this.txt_password.UseSystemPasswordChar = true;
            // 
            // txt_loginid
            // 
            this.txt_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_loginid.Location = new System.Drawing.Point(142, 99);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(145, 30);
            this.txt_loginid.TabIndex = 23;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(23, 161);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(89, 22);
            this.lbl_password.TabIndex = 22;
            this.lbl_password.Text = "Password";
            // 
            // tbl_login
            // 
            this.tbl_login.AutoSize = true;
            this.tbl_login.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_login.Location = new System.Drawing.Point(23, 99);
            this.tbl_login.Name = "tbl_login";
            this.tbl_login.Size = new System.Drawing.Size(56, 22);
            this.tbl_login.TabIndex = 21;
            this.tbl_login.Text = "Login";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(724, 489);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.btn_resetnew);
            this.Controls.Add(this.btn_newcustomer);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customermobile);
            this.Controls.Add(this.txt_Customeremail);
            this.Controls.Add(this.txt_Customername);
            this.Controls.Add(this.lbl_newpassword);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.lbl_mobile);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.lbl_newcustomer);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.tbl_login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdb_female;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.Button btn_resetnew;
        private System.Windows.Forms.Button btn_newcustomer;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.TextBox txt_customermobile;
        private System.Windows.Forms.TextBox txt_Customeremail;
        private System.Windows.Forms.TextBox txt_Customername;
        private System.Windows.Forms.Label lbl_newpassword;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.Label lbl_mobile;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_newcustomer;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label tbl_login;
    }
}

