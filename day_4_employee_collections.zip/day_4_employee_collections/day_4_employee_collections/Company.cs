﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_collections
{
    class Company
    {
        public void onleave(int id, string reason)
        {
            Console.WriteLine("Employee class : Employee on leave:" + id + "," + reason);
        }

        private int CompanyName;
        private string CompanyAddress;

        public Company(int CompanyName, string CompanyAddress)
        {
            this.CompanyName = CompanyName;
            this.CompanyAddress = CompanyAddress;


        }

        private List<Employee> employeelist = new List<Employee>();

        public void AddEmployee(Employee emp)
        {
            Employee.delleave d = new Employee.delleave(this.onleave);
    
            emp.evtleave += d;
            employeelist.Add(emp);
        }
        public Employee Find(int ID)
        {
            foreach (Employee e in employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    return e;
                }
            }
            return null;
        }
        public bool Remove(int ID)
        {
            foreach (Employee e in employeelist)
            {
                if (e.PEmployeeID == ID)
                {
                    employeelist.Remove(e);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach (Employee e in employeelist)
            {
                Console.WriteLine(e.PEmployeeID + " " + e.PEmployeeName + " " + e.PEmployeeCity);
            }

        }
    }
}
