﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_13_win_reflection
{
    class Test
    {
        public void call1() { }
        public void call2() { }

    }
}
