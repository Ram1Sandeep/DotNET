﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_5_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("E1", "Ajay");
            names.Add("E2", "Vijay");
            names.Add("E3", "John");
            names.Add("E4", "Rosy");

            foreach(KeyValuePair<string,string> s in names)
            {
                Console.WriteLine(s.Key + " " + s.Value);
            }

            foreach(string k in names.Keys)
            {
                Console.WriteLine(k);

            }
            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }
            string name = names["E1"];
            Console.WriteLine(name);


            Console.ReadLine();
        }
    }
}
