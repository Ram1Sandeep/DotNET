﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_DAL_Assignment.Models;

namespace MVC_DAL_Assignment.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: Employees
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(EmployeeModel model)
        {
            if (ModelState.IsValid)
            {
                EmployeesDAL dal = new EmployeesDAL();
                int id = dal.AddEmployee(model);
                ViewBag.msg = "Employee ID :" + id;
            }
            return View();

        }
        public ActionResult Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Search(string key)
        {
            EmployeesDAL dal = new EmployeesDAL();
            List<EmployeeModel> list = dal.SearchEmployee(key);
            return View(list); 
        }
        public ActionResult Delete(int id)
        {
            EmployeesDAL dal = new EmployeesDAL();
            dal.Delete(id);
            return View();`
        }
        public ActionResult Edit(int id)
        {
            EmployeesDAL dal = new EmployeesDAL();
            EmployeeModel model = dal.Find(id);
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(EmployeeModel model)
        {
            EmployeesDAL dal = new EmployeesDAL();
            dal.update(model.EmployeeID, model.EmployeeName, model.EmployeeCity);
            return View("EmployeeUpdatedView");
        }
        public ActionResult Details(int id)
        {
            EmployeesDAL dal = new EmployeesDAL();
            EmployeeModel model = dal.Find(id);
            return View(model);
        }
    }
}