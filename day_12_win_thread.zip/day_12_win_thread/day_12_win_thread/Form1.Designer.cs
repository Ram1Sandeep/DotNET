﻿namespace day_12_win_thread
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_new_thread = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_new_thread
            // 
            this.btn_new_thread.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_new_thread.Location = new System.Drawing.Point(203, 127);
            this.btn_new_thread.Name = "btn_new_thread";
            this.btn_new_thread.Size = new System.Drawing.Size(206, 58);
            this.btn_new_thread.TabIndex = 0;
            this.btn_new_thread.Text = "New Thread";
            this.btn_new_thread.UseVisualStyleBackColor = true;
            this.btn_new_thread.Click += new System.EventHandler(this.btn_new_thread_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 338);
            this.Controls.Add(this.btn_new_thread);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_new_thread;
    }
}

