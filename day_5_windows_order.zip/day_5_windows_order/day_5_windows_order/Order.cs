﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_5_windows_order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private int ItemID;
        private int ItemQty;
        private int ItemPrice;
        private string DeliveryAddress;
        

        public Order(int OrderID,string CustomerName,int ItemID,int ItemQty,int ItemPrice,string DeliveryAddress)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemID = ItemID;
            this.ItemQty = ItemQty;
            this.ItemPrice = ItemPrice;
            this.DeliveryAddress = DeliveryAddress;
        }
        public int GetOrderValue()
        {
            return this.ItemQty * this.ItemPrice;
        }

    }
}
