create database PathFrontADO

use PathFrontADO

create table tbl_employees
(
EmployeeID int identity(1000,1),
EmployeeName varchar(100),
EmployeeCity varchar(100),
EmployeePassword varchar(100),
EmployeeDOJ datetime
)
select * from tbl_employees

create table tbl_customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100),
CustomerCity varchar(100),
CustomerPassword varchar(100),
CustomerAddress varchar(100), 
CustomerMobileNo varchar(15),
CustomerEmailID varchar(100)
)
select * from tbl_customers
