﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    class HR 
    {
       public void GetEmployee(IHREmp e)
        {
            string Address = e.GetAddress();
            Console.WriteLine("Employee Address" + Address);
            int Salary = e.GetEmployeeSalary();
            Console.WriteLine("Employee Salary" + Salary);
            int ID = e.GetEmployeeID();
            Console.WriteLine("Employee ID" + ID);


          
            
             


        }
    }
}
