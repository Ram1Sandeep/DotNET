alter table tbl_students

add  StudentPassword varchar(100);

select * from tbl_students


create proc proc_addstudent(@name varchar(100),@city varchar(100),@address varchar(100),@emailid varchar(100),@password varchar(100))
as
insert tbl_students values(@name,@city,@address,@emailid,@password)
return @@identity
--2


create proc proc_studentsdetails(@id int)
as
select * from tbl_students where StudentID=@id
--3


create proc proc_showstudents(@city varchar(100))
as
select * from tbl_students where StudentCity=@city
--4


create proc proc_searchstudents(@key varchar(100))
as
select * from tbl_students where
StudentID like '%'+@key+'%'or StudentName like '%'+@key+'%' or StudentCity like '%'+@key+'%'or StudentAddress like '%'+@key+'%'or StudentEmailID like '%'+@key+'%';
--5


create proc proc_updatestudents(@id int,@city varchar(100),@password varchar(100))
as
update tbl_students set StudentCity=@city,StudentPassword=@password where StudentID=@id
return @@rowcount
--6

create proc proc_deletestudents(@id int)
as
delete tbl_employees where EmployeeID=@id
return @@rowcount
--7


create proc proc_login3(@id int,@password varchar(100))
as
declare @count int
select @count=count(*) from tbl_students where 
StudentID=@id and StudentPassword=@password
return @count 
--8


select * from tbl_students