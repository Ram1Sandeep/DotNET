﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_13_attributes
{
   [Developer("1001","John")]
    class Test
    {
        [Obsolete("Not in use,use abc")]
        [Developer("1002", "David")]

        public void call()
        {
            Console.WriteLine("Call function called");
        }
    }
}
