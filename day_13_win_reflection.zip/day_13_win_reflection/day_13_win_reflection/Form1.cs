﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace day_13_win_reflection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_read_type_Click(object sender, EventArgs e)
        {
            //Test obj = new Test();
            //Type t = obj.GetType();
            Type t = typeof(Test);

            MessageBox.Show(t.FullName);
            MessageBox.Show(t.Assembly.FullName);
            foreach(MethodInfo m in t.GetMethods())
            {
                MessageBox.Show(m.Name);
            }

        }
        Assembly asm;
        private void btn_load_assembly_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();
            string dlladdress = dialog.FileName;
            asm = Assembly.LoadFile(dlladdress);
            MessageBox.Show(asm.FullName);

            lst_classes.Items.Clear();

            foreach(Type t in asm.GetTypes())
            {
                lst_classes.Items.Add(t.FullName);
            }

        }

        private void lst_classes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = lst_classes.Text;
            Type t = asm.GetType(name);

            lst_methods.Items.Clear();
            foreach(MethodInfo m in t.GetMethods())
            {
                lst_methods.Items.Add(m.Name);
            }

        }

        private void btn_call_Click(object sender, EventArgs e)
        {
            Type t = asm.GetType(lst_classes.Text);
            Object obj = Activator.CreateInstance(t);
            MethodInfo m = t.GetMethod(lst_methods.Text);
            Object returndata = m.Invoke(obj, null);
            MessageBox.Show(returndata.ToString());
        }
    }
}
