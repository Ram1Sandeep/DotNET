﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public Order(int OrderID,string CustomerName,string ItemName,int ItemPrice,int ItemQuantity)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
            

        }
        public int GetOrderAmount()
        {
            return this.ItemQuantity * this.ItemPrice;

        }
        public string GetDetails()
        {
            return this.OrderID + " " + this.CustomerName + " " + this.ItemName + " " + this.ItemPrice + " " + this.ItemQuantity;
        }

    }
}
