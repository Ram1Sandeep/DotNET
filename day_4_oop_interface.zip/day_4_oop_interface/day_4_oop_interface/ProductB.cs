﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_oop_interface
{
    class ProductB:IProductTransport
    {
        private int PID;
        private string PName;

        public ProductB(int PID, string PName)
        {
            this.PID = PID;
            this.PName = PName;

        }
        public int GetPrice()
        {
            return 2000;

        }
        public string GetDetails()
        {
            return this.PID + " " + this.PName;
        }
        public void start()
        {

        }
        public void stop()
        {

        }

        public string GetAddress()
        {
            return "DEF, Chennai";
        }
    }
}
