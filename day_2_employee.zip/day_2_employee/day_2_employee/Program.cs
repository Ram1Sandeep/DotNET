﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter EmployeeID");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Employee City");
            string city = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary");
            double salary = Convert.ToDouble(Console.ReadLine());

            Employee obj = new Employee(id, name, city, salary);
            Console.WriteLine("Enter Number of days");
            int days = Convert.ToInt32(Console.ReadLine());


            Double a = obj.GetEmployeeSalary(days);
            Console.WriteLine(a);

            string b = obj.Getdetails();
            Console.WriteLine(b);
            Console.ReadLine();

        }
    }
}
