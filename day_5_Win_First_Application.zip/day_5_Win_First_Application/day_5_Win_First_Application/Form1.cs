﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_Win_First_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("Enter Login ID");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string loginid = txt_loginid.Text;
                string password = txt_password.Text;
                if(loginid=="admin@gmail.com"&&password=="pass@123")
                {
                    MessageBox.Show("Valid User");
                    frm_sum obj = new frm_sum();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }

            }
        }
    }
}
