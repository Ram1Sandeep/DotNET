﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_MiniProject
{
    public partial class NewTransaction : Form
    {
        public NewTransaction()
        {
            InitializeComponent();
        }

        private void NewTransaction_Load(object sender, EventArgs e)
        {
            cb_transactiontype.Items.Add("withdraw");
            cb_transactiontype.Items.Add("Deposit");

            BankDAL dal = new BankDAL();
            List<int> x = dal.showOnlyAccounts(Test.cid);

            foreach (int y in x)
            {
                cmb_accountid.Items.Add(y);
            }

            // BankDAL x = new BankDAL();

            // cmb_accountid.Items. = x.showOnlyAccounts(Test.cid);
        }

        private void btn_makepayment_Click(object sender, EventArgs e)
        {
            if (cmb_accountid.Text == string.Empty)
            {
                MessageBox.Show("Enter AccountID");
            }else if (cb_transactiontype.Text == string.Empty)
            {
                MessageBox.Show("Select Transaction Type");

            }
            else if(txt_amount.Text==string.Empty)
            {
                MessageBox.Show("Enter Amount");
            }
            else
            {
                BankDAL dal = new BankDAL();

                Transaction t = new Transaction();
                t.AccountID = Convert.ToInt32(cmb_accountid.Text);
                t.Transtype = cb_transactiontype.Text;
                t.Amount =Convert.ToInt32(txt_amount.Text);
                int id;
                int bal = dal.AccountBalance(Convert.ToInt32(cmb_accountid.Text));
           
                if (t.Transtype == "Deposit")
                {
                    id = dal.addTransaction(t);
                    MessageBox.Show("Transaction ID is" + id);
                }
               
               if (t.Transtype=="withdraw")
                {
                    if(t.Amount<bal)
                    {
                        id = dal.addTransaction(t);
                        MessageBox.Show("Transaction ID is" + id);
                    }
                    else
                    {
                        MessageBox.Show("Insufficient Balance" + bal);
                    }

                }



            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
