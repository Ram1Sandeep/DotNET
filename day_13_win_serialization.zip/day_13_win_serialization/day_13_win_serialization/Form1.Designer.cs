﻿namespace day_13_win_serialization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_productid = new System.Windows.Forms.Label();
            this.txt_productid = new System.Windows.Forms.TextBox();
            this.txt_productname = new System.Windows.Forms.TextBox();
            this.lbl_productname = new System.Windows.Forms.Label();
            this.txt_productprice = new System.Windows.Forms.TextBox();
            this.lbl_productprice = new System.Windows.Forms.Label();
            this.btn_deserialize = new System.Windows.Forms.Button();
            this.btn_serialize = new System.Windows.Forms.Button();
            this.btn_xml_serialize = new System.Windows.Forms.Button();
            this.btn_xml_deserialize = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_productid
            // 
            this.lbl_productid.AutoSize = true;
            this.lbl_productid.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productid.Location = new System.Drawing.Point(25, 31);
            this.lbl_productid.Name = "lbl_productid";
            this.lbl_productid.Size = new System.Drawing.Size(108, 22);
            this.lbl_productid.TabIndex = 0;
            this.lbl_productid.Text = "Product ID :";
            // 
            // txt_productid
            // 
            this.txt_productid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_productid.Location = new System.Drawing.Point(220, 27);
            this.txt_productid.Name = "txt_productid";
            this.txt_productid.Size = new System.Drawing.Size(213, 26);
            this.txt_productid.TabIndex = 1;
            // 
            // txt_productname
            // 
            this.txt_productname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_productname.Location = new System.Drawing.Point(220, 83);
            this.txt_productname.Name = "txt_productname";
            this.txt_productname.Size = new System.Drawing.Size(213, 26);
            this.txt_productname.TabIndex = 3;
            // 
            // lbl_productname
            // 
            this.lbl_productname.AutoSize = true;
            this.lbl_productname.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productname.Location = new System.Drawing.Point(25, 85);
            this.lbl_productname.Name = "lbl_productname";
            this.lbl_productname.Size = new System.Drawing.Size(138, 22);
            this.lbl_productname.TabIndex = 2;
            this.lbl_productname.Text = "Product Name :";
            // 
            // txt_productprice
            // 
            this.txt_productprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_productprice.Location = new System.Drawing.Point(220, 140);
            this.txt_productprice.Name = "txt_productprice";
            this.txt_productprice.Size = new System.Drawing.Size(213, 26);
            this.txt_productprice.TabIndex = 5;
            // 
            // lbl_productprice
            // 
            this.lbl_productprice.AutoSize = true;
            this.lbl_productprice.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productprice.Location = new System.Drawing.Point(25, 144);
            this.lbl_productprice.Name = "lbl_productprice";
            this.lbl_productprice.Size = new System.Drawing.Size(130, 22);
            this.lbl_productprice.TabIndex = 4;
            this.lbl_productprice.Text = "Product Price :";
            // 
            // btn_deserialize
            // 
            this.btn_deserialize.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deserialize.Location = new System.Drawing.Point(273, 206);
            this.btn_deserialize.Name = "btn_deserialize";
            this.btn_deserialize.Size = new System.Drawing.Size(183, 43);
            this.btn_deserialize.TabIndex = 6;
            this.btn_deserialize.Text = "Deserialize";
            this.btn_deserialize.UseVisualStyleBackColor = true;
            this.btn_deserialize.Click += new System.EventHandler(this.btn_deserialize_Click);
            // 
            // btn_serialize
            // 
            this.btn_serialize.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_serialize.Location = new System.Drawing.Point(49, 206);
            this.btn_serialize.Name = "btn_serialize";
            this.btn_serialize.Size = new System.Drawing.Size(178, 43);
            this.btn_serialize.TabIndex = 7;
            this.btn_serialize.Text = "Serialize";
            this.btn_serialize.UseVisualStyleBackColor = true;
            this.btn_serialize.Click += new System.EventHandler(this.btn_serialize_Click);
            // 
            // btn_xml_serialize
            // 
            this.btn_xml_serialize.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_xml_serialize.Location = new System.Drawing.Point(49, 280);
            this.btn_xml_serialize.Name = "btn_xml_serialize";
            this.btn_xml_serialize.Size = new System.Drawing.Size(178, 43);
            this.btn_xml_serialize.TabIndex = 8;
            this.btn_xml_serialize.Text = "XML Serialize";
            this.btn_xml_serialize.UseVisualStyleBackColor = true;
            this.btn_xml_serialize.Click += new System.EventHandler(this.btn_xml_serialize_Click);
            // 
            // btn_xml_deserialize
            // 
            this.btn_xml_deserialize.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_xml_deserialize.Location = new System.Drawing.Point(273, 280);
            this.btn_xml_deserialize.Name = "btn_xml_deserialize";
            this.btn_xml_deserialize.Size = new System.Drawing.Size(183, 43);
            this.btn_xml_deserialize.TabIndex = 9;
            this.btn_xml_deserialize.Text = "XML Deserialize";
            this.btn_xml_deserialize.UseVisualStyleBackColor = true;
            this.btn_xml_deserialize.Click += new System.EventHandler(this.btn_xml_deserialize_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 374);
            this.Controls.Add(this.btn_xml_deserialize);
            this.Controls.Add(this.btn_xml_serialize);
            this.Controls.Add(this.btn_serialize);
            this.Controls.Add(this.btn_deserialize);
            this.Controls.Add(this.txt_productprice);
            this.Controls.Add(this.lbl_productprice);
            this.Controls.Add(this.txt_productname);
            this.Controls.Add(this.lbl_productname);
            this.Controls.Add(this.txt_productid);
            this.Controls.Add(this.lbl_productid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_productid;
        private System.Windows.Forms.TextBox txt_productid;
        private System.Windows.Forms.TextBox txt_productname;
        private System.Windows.Forms.Label lbl_productname;
        private System.Windows.Forms.TextBox txt_productprice;
        private System.Windows.Forms.Label lbl_productprice;
        private System.Windows.Forms.Button btn_deserialize;
        private System.Windows.Forms.Button btn_serialize;
        private System.Windows.Forms.Button btn_xml_serialize;
        private System.Windows.Forms.Button btn_xml_deserialize;
    }
}

