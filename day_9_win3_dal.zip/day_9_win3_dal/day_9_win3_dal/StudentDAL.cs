﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace day_9_win3_dal
{
    class StudentDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddStudent(Student std)
        {
            SqlCommand com_std_insert = new SqlCommand
                ("insert tbl_Students values(@name,@city,@address,@emailid,@password)", con);
            com_std_insert.Parameters.AddWithValue("@name", std.StudentName);
            com_std_insert.Parameters.AddWithValue("@city", std.StudentCity);
            com_std_insert.Parameters.AddWithValue("address", std.StudentAddress);
            com_std_insert.Parameters.AddWithValue("@emailid", std.StudentEmailID);
            com_std_insert.Parameters.AddWithValue("@password", std.StudentPassword);
            con.Open();
            com_std_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int ID = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return ID;

        }
        public Student Find(int ID)
        {
            SqlCommand com_find = new SqlCommand
                ("select * from tbl_students where studentID=@id", con);
            com_find.Parameters.AddWithValue("@id", ID);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if (dr.Read())
            {
                Student s = new Student();
                s.StudentID = dr.GetInt32(0);
                s.StudentName = dr.GetString(1);
                s.StudentCity = dr.GetString(2);
                s.StudentAddress = dr.GetString(3);
                s.StudentEmailID = dr.GetString(4);
                con.Close();
                return s;
            }
            else
            {
                return null;
            }
        }

        public bool Update(int ID, string Address)
        {
            SqlCommand com_update = new SqlCommand
                ("update tbl_students set StudentAddress=@address where StudentID = @id", con);

            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", Address);
            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand
                ("delete tbl_students where StudentID = @id", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            con.Open();
            int count = com_delete.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }


        }
        public List<Student> ShowStudent(string city)
        {
            SqlCommand com_students = new SqlCommand("proc_showstudents", con);
            com_students.Parameters.AddWithValue("@city", city);
            com_students.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_students.ExecuteReader();

            List<Student> cuslist = new List<Student>();
            while (dr.Read())
            {
                Student obj = new Student();
                obj.StudentID = dr.GetInt32(0);
                obj.StudentName = dr.GetString(1);
                obj.StudentCity = dr.GetString(2);
                obj.StudentAddress = dr.GetString(3);
                obj.StudentEmailID = dr.GetString(4);
                obj.StudentPassword = dr.GetString(5);
                cuslist.Add(obj);

            }
            con.Close();
            return cuslist;
        }
        public List<Student> SearchStudent(String Search)
        {
            SqlCommand com_search = new SqlCommand
                ("proc_searchstudents", con);
            com_search.Parameters.AddWithValue("@key", Search);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Student> cuslist = new List<Student>();
            while (dr.Read())
            {
                Student std = new Student();
                std.StudentID = dr.GetInt32(0);
                std.StudentName = dr.GetString(1);
                std.StudentCity = dr.GetString(2);
                std.StudentAddress = dr.GetString(3);
                std.StudentEmailID = dr.GetString(4);
                std.StudentPassword = dr.GetString(5);

                cuslist.Add(std);

            }
            con.Close();
            return cuslist;

        }
        public bool Login(int ID, string Password)
        {
            try
            {


                SqlCommand com_login = new SqlCommand("proc_login3", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_login.Parameters.Add(retdata);

                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }

            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            System.Windows.Forms.MessageBox.Show("After Finally");
        }
        public bool LoginSqlInjection(string ID, string Password)
        {
            SqlCommand com_login = new SqlCommand("Select count(*) from tbl_students where studentid='" + ID + "' and studentpassword='" + Password + "'", con);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }

        }
    }
}


