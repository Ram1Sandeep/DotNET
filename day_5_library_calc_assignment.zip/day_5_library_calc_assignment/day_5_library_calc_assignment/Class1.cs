﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_5_library_calc_assignment
{
    public class Library
    {
        public int GetSum(int number1,int number2)
        {
            return number1 + number2;
        }
        public int GetMultiply(int number1,int number2)
        {
            return number1 * number2;
        }
        public float GetDivide(int number1,int number2)
        {
            return number1 / number2;
        }
        public int GetSubtract(int number1,int number2)
        {
            return number1 - number2;
        }
    }
}
