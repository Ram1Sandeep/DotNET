﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_4_employee_interface
{
    class Employee:IHREmp,IAccountEmp,IManagerEmp
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private int EmployeeSalary;
        private string EmployeeAddress;
        private string EmployeeProjectDetails;
        private int EmployeeExp;
        private int EmployeeAccountNumber;
        private string EmployeeBankName;
        private int EmployeeAge;

        public Employee(int EmployeeID, string EmployeeName, string EmployeeCity, int EmployeeSalary, string EmployeeAddress,
            string EmployeeProjectDetails, int EmployeeExp, int EmployeeAccountNumber, string EmployeeBankName, int EmployeeAge)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccountNumber = EmployeeAccountNumber;
            this.EmployeeBankName = EmployeeBankName;
            this.EmployeeAge = EmployeeAge;

        }

        public string GetAddress()
        {
            return this.EmployeeAddress;
        }

        public int GetEmployeeSalary()
        {
            return  this.EmployeeSalary;
        }

        public int GetEmployeeID()
        {
            return this.EmployeeID;
        }

        public int GetEmployeeAccountNo()
        {
            return this.EmployeeAccountNumber;
        }

        public int GetEmployeeExp()
        {
            return this.EmployeeExp;
        }

        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }

     
       
    }
}
