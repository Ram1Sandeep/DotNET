create database Emp_DB1

use Emp_DB1

create table Employees
(
EmployeeID int,
EmployeeFName varchar(100),
EmployeeLname varchar(100),
EmployeeCity varchar(100),
EmployeeDOB datetime,
EmployeeSalary int,
EmployeeStatus varchar(100)
)

alter table Employees add EmployeeDept varchar(100)
alter table Employees add EmployeeDOJ datetime


insert Employees values(1001,'Ram','Sandeep','Chennai','05-04-1997',20000,'Working','CSE','01-10-2018')
insert Employees values(1002,'Mohan','Babu','Guntur','05-10-1996',20000,'Working','CSE','02-09-2017')
insert Employees values(1003,'Ram','Charan','Chennai','10-09-1998',30000,'Working','ECE','03-08-2016')
insert Employees values(1004,'Allu','Arjun','Bangalore','11-08-1991',30000,'Resign','ECE','04-07-2015')
insert Employees values(1005,'Varun','Teja','Chennai','12-07-1992',10000,'Working','EEE','05-06-2014')
insert Employees values(1006,'Sai','Dharam','Hyderabad','02-06-1993',40000,'Resign','EEE','06-05-2013')
insert Employees values(1007,'Krishna','Sai','Hyderabad','08-05-1994',40000,'Working','MECH','07-04-2012')
insert Employees values(1008,'Manchu','Manoj','Guntur','09-04-1997',50000,'Resign','MECH','08-03-2011')
insert Employees values(1009,'Vishnu','Teja','Bangalore','10-02-1997',20000,'Working','CIVIL','09-02-2010')
insert Employees values(1010,'Sudheer','Babu','Guntur','05-03-1997',60000,'Resign','CIVIL','10-01-2009')

select * from Employees where EmployeeCity='Chennai'

select * from Employees where EmployeeSalary> 25000 and employeesalary<50000

select * from Employees 
select EmployeeFName+EmployeeLName,EmployeeID,EmployeeCity from Employees

select * from Employees order by LEN(EmployeeFName) asc

select sum(EmployeeSalary) from Employees

select count(*) from Employees

select * from Employees where DATEPART(mm,employeedoj)=1

select *from employees


select *from Employees
where DATEDIFF(yy,EmployeeDOJ,GETDATE())>5

select Employeedept,count (*) from Employees group by employeedept

select EmployeeCity,count (*) from Employees group by EmployeeCity

update employees set EmployeeCity='Pune' where EmployeeCity='Chennai'

select employeedept,sum(employeeSalary) from Employees
group by EmployeeDept having sum(EmployeeSalary)>50000

select cast(EmployeeSalary as decimal(12,4)) from Employees

update employees set EmployeeStatus='Resigned' where EmployeeStatus='Working'

select *from employees where  datediff(mm,employeedoj,getdate())<=1










