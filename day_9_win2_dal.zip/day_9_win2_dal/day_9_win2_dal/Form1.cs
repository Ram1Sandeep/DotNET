﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_9_win2_dal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_newcustomer_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("Enter Name");

            }
            else if (txt_customercity.Text == string.Empty)
            {
                MessageBox.Show("Enter City");
            }
            else if (txt_customerpassword.Text == string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address");
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("Enter Mobile No");
            }
            else if (txt_customeremailid.Text == string.Empty)
            {
                MessageBox.Show("Enter Email ID");
            }
            else
            {
                string name = txt_customername.Text;
                string city = txt_customercity.Text;
                string password = txt_customerpassword.Text;
                string address = txt_customeraddress.Text;
                string mobileno = txt_customermobileno.Text;
                string emailid = txt_customeremailid.Text;
                Customer obj = new Customer();
                obj.CustomerName = name;
                obj.CustomerCity = city;
                obj.CustomerPassword = password;
                obj.CustomerAddress = address;
                obj.CustomerMobileNo = mobileno;
                obj.CustomerEmailID = emailid;

                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(obj);
                MessageBox.Show("Customer Added" + id);

            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_customername.Text = string.Empty;
            txt_customercity.Text = string.Empty;
            txt_customerpassword.Text = string.Empty;
            txt_customeraddress.Text = string.Empty;
            txt_customermobileno.Text = string.Empty;
            txt_customeremailid.Text = string.Empty;
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter Correct ID");
            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                Customer emp = dal.Find(id);
                if (emp != null)
                {
                    txt_customername.Text = emp.CustomerName;
                    txt_customerpassword.Text = emp.CustomerPassword;
                    txt_customercity.Text = emp.CustomerCity;
                    txt_customeraddress.Text = emp.CustomerAddress;
                    txt_customermobileno.Text = emp.CustomerMobileNo;
                    txt_customeremailid.Text = emp.CustomerEmailID;

                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                MessageBox.Show("Enter Address");
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                MessageBox.Show("Enter Mobile No");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                string address = txt_customeraddress.Text;
                string mobileno = txt_customermobileno.Text;

                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Update(ID, address, mobileno);
                if (status)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                MessageBox.Show("Enter ID");
            }
            else
            {
                int ID = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.Delete(ID);
                if (status)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Found");
                }

            }
        }
    }
}
