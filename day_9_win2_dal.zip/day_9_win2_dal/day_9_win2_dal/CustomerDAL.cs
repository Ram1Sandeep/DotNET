﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace day_9_win2_dal
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
            (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(Customer cus)
        {
            SqlCommand com_cus_insert = new SqlCommand
            ("proc_addcustomer", con);
            com_cus_insert.Parameters.AddWithValue("@name", cus.CustomerName);
            com_cus_insert.Parameters.AddWithValue("@city", cus.CustomerCity);
            com_cus_insert.Parameters.AddWithValue("@password", cus.CustomerPassword);
            com_cus_insert.Parameters.AddWithValue("@address", cus.CustomerAddress);
            com_cus_insert.Parameters.AddWithValue("@mobileno", cus.CustomerMobileNo);
            com_cus_insert.Parameters.AddWithValue("@emailid", cus.CustomerEmailID);
            com_cus_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_cus_insert.Parameters.Add(retdata);

            con.Open();
            com_cus_insert.ExecuteNonQuery();
            con.Close();
            int ID = Convert.ToInt32(retdata.Value);
            return ID;

        }
        public Customer Find(int ID)
        {
            SqlCommand com_Find = new SqlCommand
                ("proc_customerdetails", con);
            com_Find.Parameters.AddWithValue("@id", ID);
            com_Find.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_Find.ExecuteReader();
            if (dr.Read())
            {
                Customer c = new Customer();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerCity = dr.GetString(2);
                c.CustomerPassword = dr.GetString(3);
                c.CustomerAddress = dr.GetString(4);
                c.CustomerMobileNo = dr.GetString(5);
                c.CustomerEmailID = dr.GetString(6);
                con.Close();
                return c;

            }
            else
            {
                return null;
            }


        }
        public bool Update(int ID, string Address, string MobileNo)
        {
            SqlCommand com_update = new SqlCommand
                ("proc_updatecustomer", con);

            com_update.Parameters.AddWithValue("@id", ID);
            com_update.Parameters.AddWithValue("@address", Address);
            com_update.Parameters.AddWithValue("@mobileno", MobileNo);

            com_update.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            com_update.Parameters.Add(retdata);

            con.Open();
            int count = com_update.ExecuteNonQuery();
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public bool Delete(int ID)
        {
            SqlCommand com_delete = new SqlCommand
                ("proc_deletecustomer", con);
            com_delete.Parameters.AddWithValue("@id", ID);
            com_delete.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(retdata);
            con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(retdata.Value);
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        public List<Customer> ShowCustomer(string city)
        {
            SqlCommand com_customers = new SqlCommand("proc_showcustomers", con);
            com_customers.Parameters.AddWithValue("@city", city);
            com_customers.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_customers.ExecuteReader();

            List<Customer> cuslist = new List<Customer>();
            while (dr.Read())
            {
                Customer obj = new Customer();
                obj.CustomerID = dr.GetInt32(0);
                obj.CustomerName = dr.GetString(1);
                obj.CustomerCity = dr.GetString(2);
                obj.CustomerPassword = dr.GetString(3);
                obj.CustomerAddress = dr.GetString(4);
                obj.CustomerMobileNo = dr.GetString(5);
                obj.CustomerEmailID = dr.GetString(6);
                cuslist.Add(obj);

            }
            con.Close();
            return cuslist;
        }
        public List<Customer> SearchCustomer(String Search)
        {
            SqlCommand com_search = new SqlCommand
                ("proc_searchcustomers", con);
            com_search.Parameters.AddWithValue("@key", Search);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Customer> cuslist = new List<Customer>();
            while (dr.Read())
            {
                Customer cus = new Customer();
                cus.CustomerID = dr.GetInt32(0);
                cus.CustomerName = dr.GetString(1);
                cus.CustomerCity = dr.GetString(2);
                cus.CustomerPassword = dr.GetString(3);
                cus.CustomerAddress = dr.GetString(4);
                cus.CustomerMobileNo = dr.GetString(5);
                cus.CustomerEmailID = dr.GetString(6);

                cuslist.Add(cus);

            }
            con.Close();
            return cuslist;

        }
        public bool Login(int ID, string Password)
        {
            try
            {


                SqlCommand com_login = new SqlCommand("proc_login5", con);
                com_login.Parameters.AddWithValue("@id", ID);
                com_login.Parameters.AddWithValue("@password", Password);
                com_login.CommandType = CommandType.StoredProcedure;
                SqlParameter retdata = new SqlParameter();
                retdata.Direction = ParameterDirection.ReturnValue;

                com_login.Parameters.Add(retdata);

                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(retdata.Value);
                if (count > 0)
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }

            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            System.Windows.Forms.MessageBox.Show("After Finally");
        }
        public bool LoginSqlInjection(string ID, string Password)
        {
            SqlCommand com_login = new SqlCommand("Select count(*) from tbl_customers where customerid='" + ID + "' and customerpassword='" + Password + "'", con);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }

        }

    }
}

