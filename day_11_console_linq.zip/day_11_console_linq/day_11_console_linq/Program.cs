﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_11_console_linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer { CustomerID = 1, CustomerAge = 25, CustomerCity = "Bangalore", CustomerName = "Ram" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 26, CustomerCity = "Guntur", CustomerName = "Sai" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 27, CustomerCity = "Guntur", CustomerName = "Praveen" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 28, CustomerCity = "Guntur", CustomerName = "Kiran" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 29, CustomerCity = "Vijayawada", CustomerName = "Mani" });

            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "Oneplus 5", ItemPrice = 30000 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 1, ItemName = "Oneplus 5T", ItemPrice = 33000 });

            ordlist.Add(new Order { OrderID = 1003, CustomerID = 2, ItemName = "Oneplus 6", ItemPrice = 35000 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 3, ItemName = "Oneplus 6T", ItemPrice = 33000 });

            string city = "Guntur";
            var q = from c in custlist
                    where c.CustomerCity == city
                    orderby c.CustomerAge descending,c.CustomerName ascending
                    select c;

            foreach(var a in q)
            {
                Console.WriteLine(a.CustomerID + " " + a.CustomerName + " " + a.CustomerCity);

            }

            var count = (from c in custlist
                         where c.CustomerCity == city
                         select c).Count();

            Console.WriteLine(count);

            var obj = (from c in custlist
                       where c.CustomerID == 7
                       select c).FirstOrDefault();
            if (obj != null)
            {
                Console.WriteLine(obj.CustomerID + " " + obj.CustomerName + " ");
            }
            else
            {
                Console.WriteLine("Not Found");
            }

            var qdata = from c in custlist
                        where c.CustomerAge > 20
                        select new { CID = c.CustomerID, CName = c.CustomerName, CCity = c.CustomerCity };
            foreach(var p in qdata)
            {
                Console.WriteLine(p.CID + " " + p.CName + " " + p.CCity);
            }
            var joindata = from c in custlist
                           join o in ordlist
                           on c.CustomerID equals o.CustomerID
                           select new { CID = c.CustomerID, CName = c.CustomerName,
                           OID = o.OrderID, ItemName = o.ItemName, Price = o.ItemPrice };

            foreach(var j in joindata)
            {
                Console.WriteLine(j.CID + " " + j.CName + " " + j.OID + " " + j.ItemName + " "+j.Price);
            }

            Console.ReadLine();


        }
    }
}
