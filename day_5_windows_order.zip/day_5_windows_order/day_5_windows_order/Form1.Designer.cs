﻿namespace day_5_windows_order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_cname = new System.Windows.Forms.Label();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_itemqty = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.txt_orderid = new System.Windows.Forms.TextBox();
            this.txt_cname = new System.Windows.Forms.TextBox();
            this.txt_itemid = new System.Windows.Forms.TextBox();
            this.txt_itemqty = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.lbl_DAddress = new System.Windows.Forms.Label();
            this.txt_DAddress = new System.Windows.Forms.TextBox();
            this.cmb_ordercity = new System.Windows.Forms.ComboBox();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.rdb_cod = new System.Windows.Forms.RadioButton();
            this.rdb_paytm = new System.Windows.Forms.RadioButton();
            this.lbl_payment = new System.Windows.Forms.Label();
            this.btn_place = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(26, 31);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(47, 13);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "Order ID";
            // 
            // lbl_cname
            // 
            this.lbl_cname.AutoSize = true;
            this.lbl_cname.Location = new System.Drawing.Point(26, 70);
            this.lbl_cname.Name = "lbl_cname";
            this.lbl_cname.Size = new System.Drawing.Size(79, 13);
            this.lbl_cname.TabIndex = 1;
            this.lbl_cname.Text = "Custome Name";
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(26, 106);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(41, 13);
            this.lbl_itemid.TabIndex = 2;
            this.lbl_itemid.Text = "Item ID";
            // 
            // lbl_itemqty
            // 
            this.lbl_itemqty.AutoSize = true;
            this.lbl_itemqty.Location = new System.Drawing.Point(26, 138);
            this.lbl_itemqty.Name = "lbl_itemqty";
            this.lbl_itemqty.Size = new System.Drawing.Size(46, 13);
            this.lbl_itemqty.TabIndex = 3;
            this.lbl_itemqty.Text = "Item Qty";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Location = new System.Drawing.Point(26, 172);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(54, 13);
            this.lbl_itemprice.TabIndex = 4;
            this.lbl_itemprice.Text = "Item Price";
            // 
            // txt_orderid
            // 
            this.txt_orderid.Location = new System.Drawing.Point(127, 24);
            this.txt_orderid.Name = "txt_orderid";
            this.txt_orderid.Size = new System.Drawing.Size(100, 20);
            this.txt_orderid.TabIndex = 5;
            // 
            // txt_cname
            // 
            this.txt_cname.Location = new System.Drawing.Point(127, 63);
            this.txt_cname.Name = "txt_cname";
            this.txt_cname.Size = new System.Drawing.Size(100, 20);
            this.txt_cname.TabIndex = 6;
            // 
            // txt_itemid
            // 
            this.txt_itemid.Location = new System.Drawing.Point(127, 99);
            this.txt_itemid.Name = "txt_itemid";
            this.txt_itemid.Size = new System.Drawing.Size(100, 20);
            this.txt_itemid.TabIndex = 7;
            // 
            // txt_itemqty
            // 
            this.txt_itemqty.Location = new System.Drawing.Point(127, 131);
            this.txt_itemqty.Name = "txt_itemqty";
            this.txt_itemqty.Size = new System.Drawing.Size(100, 20);
            this.txt_itemqty.TabIndex = 8;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Location = new System.Drawing.Point(127, 165);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(100, 20);
            this.txt_itemprice.TabIndex = 9;
            // 
            // lbl_DAddress
            // 
            this.lbl_DAddress.AutoSize = true;
            this.lbl_DAddress.Location = new System.Drawing.Point(26, 211);
            this.lbl_DAddress.Name = "lbl_DAddress";
            this.lbl_DAddress.Size = new System.Drawing.Size(86, 13);
            this.lbl_DAddress.TabIndex = 10;
            this.lbl_DAddress.Text = "Delivery Address";
            // 
            // txt_DAddress
            // 
            this.txt_DAddress.Location = new System.Drawing.Point(127, 204);
            this.txt_DAddress.Name = "txt_DAddress";
            this.txt_DAddress.Size = new System.Drawing.Size(100, 20);
            this.txt_DAddress.TabIndex = 11;
            // 
            // cmb_ordercity
            // 
            this.cmb_ordercity.FormattingEnabled = true;
            this.cmb_ordercity.Location = new System.Drawing.Point(127, 246);
            this.cmb_ordercity.Name = "cmb_ordercity";
            this.cmb_ordercity.Size = new System.Drawing.Size(121, 21);
            this.cmb_ordercity.TabIndex = 12;
            this.cmb_ordercity.SelectedIndexChanged += new System.EventHandler(this.cmb_ordercity_SelectedIndexChanged);
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Location = new System.Drawing.Point(29, 254);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(53, 13);
            this.lbl_ordercity.TabIndex = 13;
            this.lbl_ordercity.Text = "Order City";
            // 
            // rdb_cod
            // 
            this.rdb_cod.AutoSize = true;
            this.rdb_cod.Location = new System.Drawing.Point(127, 289);
            this.rdb_cod.Name = "rdb_cod";
            this.rdb_cod.Size = new System.Drawing.Size(48, 17);
            this.rdb_cod.TabIndex = 14;
            this.rdb_cod.TabStop = true;
            this.rdb_cod.Text = "COD";
            this.rdb_cod.UseVisualStyleBackColor = true;
            // 
            // rdb_paytm
            // 
            this.rdb_paytm.AutoSize = true;
            this.rdb_paytm.Location = new System.Drawing.Point(242, 289);
            this.rdb_paytm.Name = "rdb_paytm";
            this.rdb_paytm.Size = new System.Drawing.Size(54, 17);
            this.rdb_paytm.TabIndex = 15;
            this.rdb_paytm.TabStop = true;
            this.rdb_paytm.Text = "Paytm";
            this.rdb_paytm.UseVisualStyleBackColor = true;
            // 
            // lbl_payment
            // 
            this.lbl_payment.AutoSize = true;
            this.lbl_payment.Location = new System.Drawing.Point(23, 293);
            this.lbl_payment.Name = "lbl_payment";
            this.lbl_payment.Size = new System.Drawing.Size(82, 13);
            this.lbl_payment.TabIndex = 16;
            this.lbl_payment.Text = "Payment Option";
            // 
            // btn_place
            // 
            this.btn_place.Location = new System.Drawing.Point(413, 278);
            this.btn_place.Name = "btn_place";
            this.btn_place.Size = new System.Drawing.Size(88, 28);
            this.btn_place.TabIndex = 17;
            this.btn_place.Text = "Place Order";
            this.btn_place.UseVisualStyleBackColor = true;
            this.btn_place.Click += new System.EventHandler(this.btn_place_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 328);
            this.Controls.Add(this.btn_place);
            this.Controls.Add(this.lbl_payment);
            this.Controls.Add(this.rdb_paytm);
            this.Controls.Add(this.rdb_cod);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.cmb_ordercity);
            this.Controls.Add(this.txt_DAddress);
            this.Controls.Add(this.lbl_DAddress);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemqty);
            this.Controls.Add(this.txt_itemid);
            this.Controls.Add(this.txt_cname);
            this.Controls.Add(this.txt_orderid);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemqty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.lbl_cname);
            this.Controls.Add(this.lbl_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_cname;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_itemqty;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.TextBox txt_orderid;
        private System.Windows.Forms.TextBox txt_cname;
        private System.Windows.Forms.TextBox txt_itemid;
        private System.Windows.Forms.TextBox txt_itemqty;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.Label lbl_DAddress;
        private System.Windows.Forms.TextBox txt_DAddress;
        private System.Windows.Forms.ComboBox cmb_ordercity;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.RadioButton rdb_cod;
        private System.Windows.Forms.RadioButton rdb_paytm;
        private System.Windows.Forms.Label lbl_payment;
        private System.Windows.Forms.Button btn_place;
    }
}

