﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day_2_practice3
{
    class order
    {
        private int orderid;
        private string customername;
        private string itemname;
        private int itemprice;
        private int itemquantity;

        public order(int orderid,string customername,string itemname,int itemprice,int itemquantity)
        {
            this.orderid = orderid;
            this.customername = customername;
            this.itemname = itemname;
            this.itemprice = itemprice;
            this.itemquantity = itemquantity;

            
        }
        public int getorderamount()
        {
            return this.itemprice * itemquantity;
        }
        public string getdetails()
        {
            return this.orderid+"    "+this.customername+"   "+this.itemname+"    "+this.itemprice+"   "+this.itemquantity+"   ";

        }
    }
}
