create database BankDB

use BankDB

create table tbl_customers
(
customerid int identity(1000,1) primary key,
customername varchar(100) not null,
customercity varchar(100) not null,
customerAddress varchar(100) not null unique,
customermobileno varchar(15) not null unique,
customerpanno varchar(100) not null unique,
customerpassword varchar(100) not null
)

insert tbl_customers values('ram','guntur','srinagar',1234567899,'abcd','qwerty')
insert tbl_customers values('charan','pune','vidyanagar',1234567898,'defg','qwerty')
insert tbl_customers values('krishna','guntur','arundelpet',1234567897,'abdc','qwery')
insert tbl_customers values('dharam','hyderabad','madhapur',1234567896,'pann','pass')
insert tbl_customers values('praveen','chennai','madhurai',1234567895,'panno','passw')

select * from tbl_customers



create table tbl_account
(

accountid int identity(100,1) primary key,
customerid int not null foreign key references tbl_customers(customerid),
accounttype varchar(100),
accountbalance int,
accountopendate datetime,
accountstatus varchar(100)

)

insert tbl_account values(1000,'savings',5000,'01-01-2018','open')
insert tbl_account values(1001,'current',4000,'02-02-2018','open')
insert tbl_account values(1002,'savings',3000,'03-03-2018','blocked')
insert tbl_account values(1003,'savings',2000,'04-04-2018','closed')
insert tbl_account values(1004,'current',1000,'05-05-2018','closed')

select * from tbl_account

create table tbl_transaction
(
transactionid int identity(10,1) primary key,
accountid int not null foreign key references tbl_account(accountid),
transactiontype varchar(100),
amount int check(amount>0),
transactiondate datetime
)

insert tbl_transaction values(100,'debit',1000,'02-02-2018')
insert tbl_transaction values(101,'credit',2000,'03-03-2018')
insert tbl_transaction values(102,'debit',3000,'04-04-2018')
insert tbl_transaction values(103,'credit',4000,'04-04-2018')
insert tbl_transaction values(104,'debit',5000,'05-05-2018')

select * from tbl_transaction

select top 5* from tbl_transaction where accountid=104 order by transactiondate desc
--1
select * from tbl_Transaction where  AccountId =12 and TransactionDate
  between '10-02-2016' and '10-02-2018'
--2
select * from tbl_Account where Customerid=104
--3
select tbl_customers.CustomerID,tbl_customers.CustomerName,tbl_Customers.CustomerAddress,
tbl_Customers.CustomerMobileNo,tbl_Account.AccountId,tbl_Account.AccountBalance
from tbl_customers join tbl_Account on tbl_Customers.CustomerID=tbl_Account.Customerid
--4
select tbl_Account.AccountId,tbl_Account.AccountBalance,tbl_Transaction.TransactionID,
tbl_Transaction.Amount,tbl_Transaction.TransactionType from tbl_Account join tbl_Transaction
on tbl_Account.AccountId=tbl_Transaction.AccountId
--5

select tbl_customers.CustomerID,tbl_customers.CustomerName,tbl_customers.CustomerAddress,
tbl_Customers.CustomerMobileNo,tbl_Account.AccountId,tbl_Account.AccountBalance,
tbl_Transaction.TransactionID,tbl_Transaction.Amount,tbl_Transaction.TransactionType
from tbl_customers join tbl_Account
on tbl_Customers.CustomerID=tbl_Account.Customerid 
join tbl_Transaction on tbl_Account.AccountId=tbl_Transaction.AccountId

--6

select * from tbl_customers where CustomerID in(select CustomerID from tbl_Account) 

--7

select * from tbl_customers where CustomerID not in (select CustomerID from tbl_Account) 

--8

select * from tbl_Account where AccountID in (select AccountID from tbl_Transaction)

--9

select * from tbl_Account where AccountID not  in (select AccountID from tbl_Transaction)

--10












 

