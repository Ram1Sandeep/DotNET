﻿namespace day_12_win_thread
{
    partial class frm_task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newtask = new System.Windows.Forms.Button();
            this.btn_newtask2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_newtask
            // 
            this.btn_newtask.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtask.Location = new System.Drawing.Point(167, 80);
            this.btn_newtask.Name = "btn_newtask";
            this.btn_newtask.Size = new System.Drawing.Size(164, 47);
            this.btn_newtask.TabIndex = 11;
            this.btn_newtask.Text = "New Task";
            this.btn_newtask.UseVisualStyleBackColor = true;
            this.btn_newtask.Click += new System.EventHandler(this.btn_newtask_Click);
            // 
            // btn_newtask2
            // 
            this.btn_newtask2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtask2.Location = new System.Drawing.Point(167, 180);
            this.btn_newtask2.Name = "btn_newtask2";
            this.btn_newtask2.Size = new System.Drawing.Size(164, 47);
            this.btn_newtask2.TabIndex = 12;
            this.btn_newtask2.Text = "New Task 2";
            this.btn_newtask2.UseVisualStyleBackColor = true;
            this.btn_newtask2.Click += new System.EventHandler(this.btn_newtask2_Click);
            // 
            // frm_task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 335);
            this.Controls.Add(this.btn_newtask2);
            this.Controls.Add(this.btn_newtask);
            this.Name = "frm_task";
            this.Text = "frm_task";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_newtask;
        private System.Windows.Forms.Button btn_newtask2;
    }
}