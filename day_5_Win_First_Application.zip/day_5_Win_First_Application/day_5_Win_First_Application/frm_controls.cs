﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace day_5_Win_First_Application
{
    public partial class frm_controls : Form
    {
        public frm_controls()
        {
            InitializeComponent();
        }

        private void frm_controls_Load(object sender, EventArgs e)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Chennai");
            lst_cities.Items.Add("Hyderabad");

            cmb_cities.Items.Add("PUNE");
            cmb_cities.Items.Add("CHENNAI");
            cmb_cities.Items.Add("HYDERABAD");

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if(rdb_male.Checked==false && rdb_female.Checked==false)
            {
                MessageBox.Show("Select your gender");
            }
            else
            {
                string gender = string.Empty;
                if(rdb_male.Checked)
                {
                    gender = "Male";

                }
                else
                {
                    gender = "Female";
                }
                MessageBox.Show(gender);

            }


            bool status = chk_readme.Checked;
            if(status)
            {
                MessageBox.Show("It is checked");
            }
            else
            {
                MessageBox.Show("Not Checked");
            }
            if(lst_cities.Text==string.Empty)
            {
                MessageBox.Show("Select a city");

            }
            else
            {
                string city = lst_cities.Text;
                MessageBox.Show(city);
            }
        }
    }
}
